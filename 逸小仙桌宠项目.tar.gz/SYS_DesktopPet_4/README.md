
  # 创建桌宠动画

  This is a code bundle for 创建桌宠动画. The original project is available at https://www.figma.com/design/nNu9VpMG98jWovrvRQmEsc/%E5%88%9B%E5%BB%BA%E6%A1%8C%E5%AE%A0%E5%8A%A8%E7%94%BB.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  