use tauri::Window;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
  tauri::Builder::default()
    .setup(|app| {
      if cfg!(debug_assertions) {
        app.handle().plugin(
          tauri_plugin_log::Builder::default()
            .level(log::LevelFilter::Info)
            .build(),
        )?;
      }
      Ok(())
    })
    .invoke_handler(tauri::generate_handler![set_click_through, get_screen_size])
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}

#[tauri::command]
fn set_click_through(_window: Window, enabled: bool) -> Result<(), String> {
  // 暂时实现基础版本，记录状态变化
  log::info!("Click through set to: {} (implementation in progress)", enabled);
  
  // TODO: 实现真正的点击穿透功能
  // 对于macOS，需要使用原生API
  // 对于Windows，需要使用Win32 API
  // 对于Linux，需要使用X11/Wayland API
  
  Ok(())
}

#[tauri::command]
fn get_screen_size() -> Result<(u32, u32), String> {
  // 暂时返回默认屏幕尺寸
  Ok((1920, 1080))
}
