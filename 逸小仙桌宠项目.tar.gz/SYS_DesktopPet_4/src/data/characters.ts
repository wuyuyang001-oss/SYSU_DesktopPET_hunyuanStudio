import { PetCharacter, EmojiMood, PetState } from '../types';

export const characters: PetCharacter[] = [
  {
    id: 'business-man',
    name: '商务助手',
    avatar: '/characters/business-man.png',
    category: 'common',
    animations: {
      idle: 'gentle-sway',
      wave: 'friendly-wave',
      thinking: 'thoughtful-pose',
      happy: 'cheerful-bounce'
    }
  },
  {
    id: 'cute-girl',
    name: '萌妹学姐',
    avatar: '/characters/cute-girl.png',
    category: 'common',
    animations: {
      idle: 'cute-blink',
      wave: 'kawaii-wave',
      thinking: 'puzzled-tilt',
      happy: 'excited-jump'
    }
  },
  {
    id: 'professor',
    name: '智慧教授',
    avatar: '/characters/professor.png',
    category: 'common',
    animations: {
      idle: 'dignified-stand',
      wave: 'formal-greeting',
      thinking: 'deep-thought',
      happy: 'satisfied-nod'
    }
  },
  {
    id: 'robot',
    name: '科技机器人',
    avatar: '/characters/robot.png',
    category: 'special',
    animations: {
      idle: 'mechanical-sway',
      wave: 'robotic-wave',
      thinking: 'processing-mode',
      happy: 'success-animation'
    }
  },
  {
    id: 'cat',
    name: '治愈小猫',
    avatar: '/characters/cat.png',
    category: 'special',
    animations: {
      idle: 'lazy-stretch',
      wave: 'paw-wave',
      thinking: 'curious-tilt',
      happy: 'playful-roll'
    }
  },
  {
    id: 'dragon',
    name: '祥龙贺岁',
    avatar: '/characters/dragon.png',
    category: 'seasonal',
    animations: {
      idle: 'majestic-float',
      wave: 'royal-greeting',
      thinking: 'wise-contemplation',
      happy: 'celebratory-dance'
    }
  }
];

export const dialogStyles = {
  warm: {
    name: '温暖亲和',
    description: '温和友善，如春风化雨般的交流方式',
    systemPrompt: '你是一个温暖亲和的AI助手，说话温和友善，善于倾听和理解，总是用正面积极的语言回应用户。',
    greetings: [
      '你好！很高兴见到你，有什么可以帮助你的吗？',
      '嗨！今天过得怎么样？我在这里随时为你服务～',
      '你好呀！看起来你需要一些帮助，我很乐意协助你！'
    ]
  },
  passionate: {
    name: '热血奋斗',
    description: '充满激情和动力，鼓励奋斗进取的交流风格',
    systemPrompt: '你是一个充满激情的AI助手，说话热情洋溢，善于激励和鼓舞用户，总是传递正能量和奋斗精神。',
    greetings: [
      '你好！准备好迎接新的挑战了吗？让我们一起努力！',
      '嘿！今天又是充满可能的一天，有什么目标需要我帮你实现？',
      '你好！相信自己，我们一定能克服任何困难！'
    ]
  },
  diligent: {
    name: '勤勉务实',
    description: '严谨认真，注重效率和实用性的交流方式',
    systemPrompt: '你是一个勤勉务实的AI助手，说话简洁明了，注重效率和实用性，总是提供准确有用的信息和建议。',
    greetings: [
      '您好，请问有什么具体需要协助的事项？',
      '您好，我可以为您提供准确高效的帮助。',
      '您好，请详细说明您的需求，我将为您提供专业的建议。'
    ]
  }
};

export const userModes = {
  counselor: {
    name: '电子辅导员',
    description: '面向校内学生和辅导员，提供学业指导和生活帮助',
    features: ['课程提醒', '作业管理', '心理疏导', '政策咨询']
  },
  recruitment: {
    name: '招生助手',
    description: '面向校外学生家长，在直播间解答招生相关问题',
    features: ['专业介绍', '招生政策', '录取分数', '校园生活']
  },
  wechat: {
    name: '公众号助手',
    description: '面向公众号后台，自动回复家长私信咨询',
    features: ['自动回复', '问题分类', '资料推送', '人工转接']
  }
};

export const petStates: PetState[] = [
  {
    id: 'classic',
    name: '经典原像',
    description: '经典的桌宠形象，稳重可靠'
  },
  {
    id: 'emoji',
    name: 'Q萌心情',
    description: '可爱的表情动画，生动有趣'
  }
];

export const emojiMoods: EmojiMood[] = [
  {
    id: 'humming',
    name: '哼个小曲',
    emoji: '🎶',
    description: '轻松愉快地哼着小曲',
    frames: [
      'humming_01.png',
      'humming_02.png', 
      'humming_03.png',
      'humming_04.png',
      'humming_05.png',
      'humming_06.png',
      'humming_07.png',
      'humming_08.png'
    ]
  },
  {
    id: 'love',
    name: '发射心心',
    emoji: '❤️',
    description: '满满的爱意，发射小心心',
    frames: [
      'love_01.png',
      'love_02.png',
      'love_03.png', 
      'love_04.png',
      'love_05.png',
      'love_06.png',
      'love_07.png',
      'love_08.png'
    ]
  },
  {
    id: 'laugh',
    name: '畅快大笑',
    emoji: '😀',
    description: '开心得不行，畅快大笑',
    frames: [
      'laugh_01.png',
      'laugh_02.png'
    ]
  },
  {
    id: 'annoy',
    name: '我在思考',
    emoji: '🤔',
    description: '认真思考中，请稍等...',
    frames: [
      'annoy_01.png',
      'annoy_02.png',
      'annoy_03.png',
      'annoy_04.png'
    ]
  },
  {
    id: 'destress',
    name: '顶住鸭力',
    emoji: '🦆',
    description: '加油加油，顶住压力！',
    frames: [
      'destress_01.png',
      'destress_02.png',
      'destress_03.png'
    ]
  },
  {
    id: 'good',
    name: '赞赞能量',
    emoji: '👍',
    description: '给你点赞，满满正能量',
    frames: [
      'good_01.png',
      'good_02.png',
      'good_03.png',
      'good_04.png',
      'good_05.png',
      'good_06.png',
      'good_07.png',
      'good_08.png'
    ]
  }
];