import React, { useState, useEffect } from 'react';
import { DesktopPet } from './components/DesktopPet';
import { ChatDialog } from './components/ChatDialog';
import { NotificationPanel } from './components/NotificationPanel';
import { SettingsPanel } from './components/SettingsPanel';
import { Toaster } from './components/ui/sonner';
import { usePetSettings } from './hooks/usePetSettings';
import { useNotifications } from './hooks/useNotifications';
import { useWindowSettings } from './hooks/useWindowSettings';
import { invoke } from '@tauri-apps/api/core';

export default function App() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  
  const { settings } = usePetSettings();
  const { requestNotificationPermission } = useNotifications();
  
  // 设置窗口属性
  useWindowSettings();

  // 初始化通知权限
  useEffect(() => {
    if (settings.enableNotifications) {
      requestNotificationPermission();
    }
  }, [settings.enableNotifications, requestNotificationPermission]);

  // 获取屏幕尺寸并调整窗口
  useEffect(() => {
    const getScreenSize = async () => {
      try {
        const [width, height] = await invoke<[number, number]>('get_screen_size');
        console.log(`Screen size: ${width}x${height}`);
        
        // 设置窗口为全屏
        const window = (window as any).__TAURI__?.window;
        if (window) {
          await window.setFullscreen(true);
          await window.setAlwaysOnTop(true);
        }
      } catch (error) {
        console.error('Failed to get screen size:', error);
      }
    };
    
    getScreenSize();
  }, []);

  // 处理退出桌宠
  const handleExit = () => {
    const confirmed = window.confirm('确定要退出桌宠吗？');
    if (confirmed) {
      setIsVisible(false);
    }
  };

  // 如果桌宠被隐藏，显示恢复按钮
  if (!isVisible) {
    return (
      <div className="min-h-screen bg-transparent flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl">智能桌宠助手</h1>
          <p className="text-muted-foreground">
            您的智能学习伙伴已退出
          </p>
          <button
            onClick={() => setIsVisible(true)}
            className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            重新启动桌宠
          </button>
        </div>
        <Toaster />
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen overflow-hidden"
      style={{ 
        backgroundColor: 'rgba(0, 0, 0, 0.001)',
        background: 'rgba(0, 0, 0, 0.001)',
        backdropFilter: 'none',
        WebkitBackdropFilter: 'none'
      }}
    >
      {/* 桌宠主体 */}
      <DesktopPet
        onOpenDialog={() => setIsDialogOpen(true)}
        onOpenNotifications={() => setIsNotificationOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onExit={handleExit}
      />

      {/* 对话窗口 */}
      <ChatDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        onOpenSettings={() => {
          setIsDialogOpen(false);
          setIsSettingsOpen(true);
        }}
      />

      {/* 通知面板 */}
      <NotificationPanel
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
      />

      {/* 设置面板 */}
      <SettingsPanel
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* 全局提示 */}
      <Toaster />
    </div>
  );
}