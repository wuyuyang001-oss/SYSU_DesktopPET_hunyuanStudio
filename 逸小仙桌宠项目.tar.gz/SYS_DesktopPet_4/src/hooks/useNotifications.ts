import { useState, useEffect, useCallback } from 'react';
import { NotificationItem } from '../types';

// 模拟学工平台的待办事项数据
const mockNotifications: NotificationItem[] = [
  {
    id: '1',
    title: '高等数学课程',
    content: '今天下午2:00-3:40，教学楼A-201',
    time: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2小时后
    type: 'course',
    url: 'https://platform.edu.cn/course/math',
    isRead: false
  },
  {
    id: '2',
    title: '英语作业提交截止',
    content: '英语写作作业今晚11:59截止提交',
    time: new Date(Date.now() + 8 * 60 * 60 * 1000), // 8小时后
    type: 'assignment',
    url: 'https://platform.edu.cn/assignment/english',
    isRead: false
  },
  {
    id: '3',
    title: '班级会议',
    content: '明天上午10:00班级会议，请准时参加',
    time: new Date(Date.now() + 20 * 60 * 60 * 1000), // 20小时后
    type: 'meeting',
    isRead: false
  }
];

export function useNotifications() {
  const [notifications, setNotifications] = useState<NotificationItem[]>(mockNotifications);
  const [unreadCount, setUnreadCount] = useState(0);

  // 计算未读数量
  useEffect(() => {
    const count = notifications.filter(n => !n.isRead).length;
    setUnreadCount(count);
  }, [notifications]);

  // 检查需要提醒的通知（30分钟和5分钟前）
  const checkNotifications = useCallback(() => {
    const now = new Date();
    const upcomingNotifications = notifications.filter(notification => {
      const timeDiff = notification.time.getTime() - now.getTime();
      const minutesDiff = timeDiff / (1000 * 60);
      
      // 30分钟或5分钟前提醒
      return (Math.abs(minutesDiff - 30) < 1) || (Math.abs(minutesDiff - 5) < 1);
    });

    upcomingNotifications.forEach(notification => {
      const timeDiff = notification.time.getTime() - now.getTime();
      const minutesDiff = Math.round(timeDiff / (1000 * 60));
      
      // 显示系统通知
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(`${minutesDiff}分钟后: ${notification.title}`, {
          body: notification.content,
          icon: '/favicon.ico',
          tag: notification.id
        });
      }
    });
  }, [notifications]);

  // 每分钟检查一次通知
  useEffect(() => {
    const interval = setInterval(checkNotifications, 60 * 1000);
    return () => clearInterval(interval);
  }, [checkNotifications]);

  // 请求通知权限
  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      await Notification.requestPermission();
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, isRead: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, isRead: true }))
    );
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    removeNotification,
    requestNotificationPermission
  };
}