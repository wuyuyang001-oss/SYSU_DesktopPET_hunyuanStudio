import { useEffect, useRef, useCallback } from 'react';
import { invoke } from '@tauri-apps/api/core';

// 防抖函数
function debounce<T extends (...args: any[]) => void>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

export function useClickThrough() {
  const petRef = useRef<HTMLDivElement>(null);
  const lastStateRef = useRef<boolean | null>(null);

  const handleMouseMove = useCallback((event: MouseEvent) => {
    if (!petRef.current) return;

    const rect = petRef.current.getBoundingClientRect();
    const isOverPet = 
      event.clientX >= rect.left &&
      event.clientX <= rect.right &&
      event.clientY >= rect.top &&
      event.clientY <= rect.bottom;

    // 只有当状态改变时才调用API，避免频繁调用
    const shouldEnableClickThrough = !isOverPet;
    if (lastStateRef.current !== shouldEnableClickThrough) {
      lastStateRef.current = shouldEnableClickThrough;
      
      invoke('set_click_through', { enabled: shouldEnableClickThrough })
        .catch(err => console.error('Failed to set click through:', err));
    }
  }, []);

  // 使用防抖优化性能
  const debouncedHandleMouseMove = useCallback(
    debounce(handleMouseMove, 16), // 60fps
    [handleMouseMove]
  );

  useEffect(() => {
    // 添加全局鼠标移动监听
    document.addEventListener('mousemove', debouncedHandleMouseMove);

    return () => {
      document.removeEventListener('mousemove', debouncedHandleMouseMove);
      // 清理时取消点击穿透
      invoke('set_click_through', { enabled: false }).catch(console.error);
    };
  }, [debouncedHandleMouseMove]);

  return petRef;
}
