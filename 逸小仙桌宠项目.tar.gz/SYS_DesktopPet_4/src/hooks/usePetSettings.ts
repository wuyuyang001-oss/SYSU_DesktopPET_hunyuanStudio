import { useState, useEffect } from 'react';
import { PetSettings } from '../types';

const defaultSettings: PetSettings = {
  character: 'business-man',
  petState: 'classic',
  emojiMood: 'humming',
  dialogStyle: 'warm',
  isMuted: false,
  enableNotifications: true,
  position: { x: window.innerWidth - 200, y: window.innerHeight - 200 },
  size: 'medium',
  transparency: 0.9
};

export function usePetSettings() {
  const [settings, setSettings] = useState<PetSettings>(() => {
    try {
      const saved = localStorage.getItem('pet-settings');
      return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
    } catch {
      return defaultSettings;
    }
  });

  useEffect(() => {
    localStorage.setItem('pet-settings', JSON.stringify(settings));
  }, [settings]);

  const updateSettings = (updates: Partial<PetSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
    localStorage.removeItem('pet-settings');
  };

  return {
    settings,
    updateSettings,
    resetSettings
  };
}