import { useState, useEffect, useCallback } from 'react';
import { usePetSettings } from './usePetSettings';

export type DisplayMode = 'default' | 'sidebar' | 'compact';
export type PanelType = 'dialog' | 'notification' | 'settings';

interface LayoutInfo {
  mode: DisplayMode;
  position: 'left' | 'right' | 'top' | 'bottom';
  availableSpace: {
    width: number;
    height: number;
  };
}

interface PanelDimensions {
  dialog: { width: 512, height: 600 }; // max-w-2xl, h-[600px]
  notification: { width: 384, height: 500 }; // max-w-md, h-[500px]
  settings: { width: 512, height: 640 }; // max-w-2xl, max-h-[80vh]
}

const PANEL_DIMENSIONS: PanelDimensions = {
  dialog: { width: 512, height: 600 },
  notification: { width: 384, height: 500 },
  settings: { width: 512, height: 640 }
};

const SIDEBAR_WIDTH = 400;
const COMPACT_WIDTH = 320;
const MARGIN = 20; // 安全边距

export function useLayoutDetection(panelType: PanelType) {
  const { settings } = usePetSettings();
  const [layoutInfo, setLayoutInfo] = useState<LayoutInfo>({
    mode: 'default',
    position: 'right',
    availableSpace: { width: 0, height: 0 }
  });

  const detectLayout = useCallback(() => {
    const petPosition = settings.position;
    const petSize = settings.size === 'small' ? 60 : settings.size === 'large' ? 140 : 100;
    const screenWidth = window.innerWidth;
    const screenHeight = window.innerHeight;
    
    const panelDimensions = PANEL_DIMENSIONS[panelType];
    
    // 计算桌宠周围的可用空间
    const spaceRight = screenWidth - (petPosition.x + petSize + MARGIN);
    const spaceLeft = petPosition.x - MARGIN;
    const spaceTop = petPosition.y - MARGIN;
    const spaceBottom = screenHeight - (petPosition.y + petSize + MARGIN);
    
    // 判断是否有足够空间显示完整面板
    const canShowDefault = 
      (spaceRight >= panelDimensions.width && screenHeight >= panelDimensions.height) ||
      (spaceLeft >= panelDimensions.width && screenHeight >= panelDimensions.height) ||
      (screenWidth >= panelDimensions.width && spaceTop >= panelDimensions.height) ||
      (screenWidth >= panelDimensions.width && spaceBottom >= panelDimensions.height);
    
    // 判断是否可以显示侧边栏
    const canShowSidebar = spaceRight >= SIDEBAR_WIDTH || spaceLeft >= SIDEBAR_WIDTH;
    
    let mode: DisplayMode = 'default';
    let position: 'left' | 'right' | 'top' | 'bottom' = 'right';
    let availableSpace = { width: screenWidth, height: screenHeight };
    
    if (!canShowDefault) {
      if (canShowSidebar) {
        mode = 'sidebar';
        if (spaceRight >= SIDEBAR_WIDTH) {
          position = 'right';
          availableSpace = { width: SIDEBAR_WIDTH, height: screenHeight };
        } else {
          position = 'left';
          availableSpace = { width: SIDEBAR_WIDTH, height: screenHeight };
        }
      } else {
        mode = 'compact';
        // 紧凑模式优先选择空间较大的一侧
        if (spaceRight >= spaceLeft && spaceRight >= COMPACT_WIDTH) {
          position = 'right';
          availableSpace = { width: Math.min(spaceRight, COMPACT_WIDTH), height: screenHeight };
        } else if (spaceLeft >= COMPACT_WIDTH) {
          position = 'left';
          availableSpace = { width: Math.min(spaceLeft, COMPACT_WIDTH), height: screenHeight };
        } else {
          // 如果左右都不够，尝试上下
          if (spaceBottom >= spaceTop) {
            position = 'bottom';
            availableSpace = { width: screenWidth, height: Math.min(spaceBottom, 400) };
          } else {
            position = 'top';
            availableSpace = { width: screenWidth, height: Math.min(spaceTop, 400) };
          }
        }
      }
    } else {
      // 默认模式下选择最佳位置
      if (spaceRight >= panelDimensions.width) {
        position = 'right';
      } else if (spaceLeft >= panelDimensions.width) {
        position = 'left';
      } else if (spaceBottom >= panelDimensions.height) {
        position = 'bottom';
      } else {
        position = 'top';
      }
    }
    
    setLayoutInfo({ mode, position, availableSpace });
  }, [settings.position, settings.size, panelType]);

  // 监听桌宠位置变化和窗口大小变化
  useEffect(() => {
    detectLayout();
  }, [detectLayout]);

  useEffect(() => {
    const handleResize = () => {
      detectLayout();
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [detectLayout]);

  return layoutInfo;
}

// 获取面板的绝对位置
export function getPanelPosition(
  petPosition: { x: number; y: number },
  petSize: number,
  layoutInfo: LayoutInfo,
  panelType: PanelType
): { x: number; y: number } {
  const panelDimensions = PANEL_DIMENSIONS[panelType];
  const screenWidth = window.innerWidth;
  const screenHeight = window.innerHeight;

  switch (layoutInfo.mode) {
    case 'sidebar':
      if (layoutInfo.position === 'right') {
        return {
          x: Math.min(petPosition.x + petSize + MARGIN, screenWidth - SIDEBAR_WIDTH),
          y: 0
        };
      } else {
        return {
          x: Math.max(petPosition.x - SIDEBAR_WIDTH - MARGIN, 0),
          y: 0
        };
      }

    case 'compact':
      if (layoutInfo.position === 'right') {
        return {
          x: Math.min(petPosition.x + petSize + MARGIN, screenWidth - COMPACT_WIDTH),
          y: Math.max(0, Math.min(petPosition.y, screenHeight - 400))
        };
      } else if (layoutInfo.position === 'left') {
        return {
          x: Math.max(petPosition.x - COMPACT_WIDTH - MARGIN, 0),
          y: Math.max(0, Math.min(petPosition.y, screenHeight - 400))
        };
      } else if (layoutInfo.position === 'bottom') {
        return {
          x: Math.max(0, Math.min(petPosition.x - COMPACT_WIDTH / 2, screenWidth - COMPACT_WIDTH)),
          y: Math.min(petPosition.y + petSize + MARGIN, screenHeight - 400)
        };
      } else {
        return {
          x: Math.max(0, Math.min(petPosition.x - COMPACT_WIDTH / 2, screenWidth - COMPACT_WIDTH)),
          y: Math.max(petPosition.y - 400 - MARGIN, 0)
        };
      }

    default:
      // 默认模式居中显示
      return {
        x: Math.max(0, (screenWidth - panelDimensions.width) / 2),
        y: Math.max(0, (screenHeight - panelDimensions.height) / 2)
      };
  }
}