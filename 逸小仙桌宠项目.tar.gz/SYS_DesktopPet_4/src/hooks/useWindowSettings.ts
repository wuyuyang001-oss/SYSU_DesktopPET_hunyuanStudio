import { useEffect } from 'react';
import { invoke } from '@tauri-apps/api/core';

export function useWindowSettings() {
  useEffect(() => {
    const setupWindow = async () => {
      try {
        // 获取当前窗口
        const { getCurrentWindow } = await import('@tauri-apps/api/window');
        const window = getCurrentWindow();
        
        // 设置窗口属性
        await window.setFullscreen(true);
        await window.setAlwaysOnTop(true);
        await window.setDecorations(false);
        await window.setTransparent(true);
        await window.setSkipTaskbar(true);
        
        console.log('窗口设置完成');
      } catch (error) {
        console.error('设置窗口属性失败:', error);
      }
    };
    
    setupWindow();
  }, []);
}

