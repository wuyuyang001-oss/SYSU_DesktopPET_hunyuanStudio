// 桌宠系统类型定义

export interface PetCharacter {
  id: string;
  name: string;
  avatar: string;
  category: 'common' | 'special' | 'seasonal';
  animations: {
    idle: string;
    wave: string;
    thinking: string;
    happy: string;
  };
}

export interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isVoice?: boolean;
}

export interface NotificationItem {
  id: string;
  title: string;
  content: string;
  time: Date;
  type: 'course' | 'assignment' | 'meeting' | 'reminder';
  url?: string;
  isRead: boolean;
}

export interface PetSettings {
  character: string;
  petState: 'classic' | 'emoji';
  emojiMood: 'humming' | 'love' | 'laugh' | 'annoy' | 'destress' | 'good';
  dialogStyle: 'warm' | 'passionate' | 'diligent';
  isMuted: boolean;
  enableNotifications: boolean;
  position: { x: number; y: number };
  size: 'small' | 'medium' | 'large';
  transparency: number;
}

export interface UserProfile {
  role: 'student' | 'counselor' | 'parent';
  mode: 'counselor' | 'recruitment' | 'wechat';
  name?: string;
  studentId?: string;
}

export type PetAnimation = 'idle' | 'wave' | 'thinking' | 'happy' | 'bounce' | 'sleep';

export interface EmojiMood {
  id: 'humming' | 'love' | 'laugh' | 'annoy' | 'destress' | 'good';
  name: string;
  emoji: string;
  description: string;
  frames: string[];
}

export interface PetState {
  id: 'classic' | 'emoji';
  name: string;
  description: string;
}

export interface VoiceSettings {
  enabled: boolean;
  language: 'zh-CN' | 'en-US';
  rate: number;
  pitch: number;
  volume: number;
}