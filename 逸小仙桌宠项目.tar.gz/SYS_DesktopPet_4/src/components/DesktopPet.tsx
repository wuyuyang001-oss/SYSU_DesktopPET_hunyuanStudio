import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { usePetSettings } from '../hooks/usePetSettings';
import { useClickThrough } from '../hooks/useClickThrough';
import { characters, emojiMoods } from '../data/characters';
import { PetAnimation } from '../types';
import { PetContextMenu } from './PetContextMenu';
import characterImage from '../assets/f907a1206897595d95a8bb4eb7c6380b1fb04949.png';

interface DesktopPetProps {
  onOpenDialog: () => void;
  onOpenNotifications: () => void;
  onOpenSettings: () => void;
  onExit: () => void;
}

export function DesktopPet({
  onOpenDialog,
  onOpenNotifications,
  onOpenSettings,
  onExit
}: DesktopPetProps) {
  const { settings, updateSettings } = usePetSettings();
  const [currentAnimation, setCurrentAnimation] = useState<PetAnimation>('idle');
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef<HTMLDivElement>(null);
  const clickThroughRef = useClickThrough();

  const currentCharacter = characters.find(c => c.id === settings.character) || characters[0];
  const currentMood = emojiMoods.find(m => m.id === settings.emojiMood) || emojiMoods[0];
  
  // 当前帧索引（用于gif动画）
  const [currentFrame, setCurrentFrame] = useState(0);

  // 动画循环
  useEffect(() => {
    if (settings.petState === 'classic') {
      const animations: PetAnimation[] = ['idle', 'wave', 'thinking', 'happy'];
      let currentIndex = 0;

      const animationInterval = setInterval(() => {
        if (!isDragging && !contextMenu) {
          currentIndex = (currentIndex + 1) % animations.length;
          setCurrentAnimation(animations[currentIndex]);
        }
      }, 3000 + Math.random() * 2000); // 随机3-5秒切换动画

      return () => clearInterval(animationInterval);
    }
  }, [isDragging, contextMenu, settings.petState]);

  // Q萌心情帧动画
  useEffect(() => {
    if (settings.petState === 'emoji') {
      const frameInterval = setInterval(() => {
        if (!isDragging && !contextMenu) {
          setCurrentFrame(prev => (prev + 1) % currentMood.frames.length);
        }
      }, 200); // 每200ms切换一帧

      return () => clearInterval(frameInterval);
    }
  }, [isDragging, contextMenu, settings.petState, currentMood.frames.length]);

  // 处理右键菜单
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    setContextMenu({ x: e.clientX, y: e.clientY });
  };

  // 关闭右键菜单
  const handleCloseMenu = () => {
    setContextMenu(null);
  };

  // 处理拖拽
  const handleDragEnd = (event: any, info: any) => {
    const newPosition = {
      x: Math.max(0, Math.min(window.innerWidth - 120, settings.position.x + info.offset.x)),
      y: Math.max(0, Math.min(window.innerHeight - 120, settings.position.y + info.offset.y))
    };
    updateSettings({ position: newPosition });
    setIsDragging(false);
  };

  const handleDragStart = () => {
    setIsDragging(true);
    setContextMenu(null);
  };

  // 获取尺寸
  const getSize = () => {
    switch (settings.size) {
      case 'small': return Math.round(60 * 1.3); // 78
      case 'large': return Math.round(140 * 1.3); // 182
      default: return Math.round(100 * 1.3); // 130
    }
  };

  // 获取动画变体
  const getAnimationVariants = () => {
    const baseVariants = {
      idle: {
        rotate: [0, -2, 2, 0],
        transition: { duration: 4, repeat: Infinity }
      },
      wave: {
        rotate: [0, -10, 10, -10, 0],
        x: [0, -5, 5, 0],
        transition: { duration: 2, repeat: 1 }
      },
      thinking: {
        rotate: [0, -5, -3, 0],
        y: [0, -3, 0],
        transition: { duration: 3, repeat: Infinity }
      },
      happy: {
        rotate: [0, -15, 15, -10, 0],
        x: [0, -8, 8, -4, 0],
        y: [0, -5, 0, -2, 0],
        transition: { duration: 1.5, repeat: 1 }
      }
    };
    return baseVariants;
  };

  const size = getSize();

  // 处理状态切换
  const handleStateChange = (state: 'classic' | 'emoji', mood?: 'humming' | 'love' | 'laugh' | 'annoy' | 'destress' | 'good') => {
    if (state === 'emoji' && mood) {
      updateSettings({ petState: state, emojiMood: mood });
    } else {
      updateSettings({ petState: state });
    }
    setCurrentFrame(0); // 重置帧
  };

  return (
    <>
      <motion.div
        ref={(el) => {
          dragRef.current = el;
          if (clickThroughRef.current) {
            clickThroughRef.current = el;
          }
        }}
        drag
        dragMomentum={false}
        dragTransition={{ bounceStiffness: 600, bounceDamping: 20 }}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onContextMenu={handleContextMenu}
        onClick={() => onOpenDialog()}
        initial={{ x: settings.position.x, y: settings.position.y }}
        animate={{ 
          x: settings.position.x, 
          y: settings.position.y,
          opacity: settings.transparency 
        }}
        transition={{
          x: { type: "spring", stiffness: 300, damping: 30 },
          y: { type: "spring", stiffness: 300, damping: 30 },
          opacity: { duration: 0.2 }
        }}
        whileHover={{ rotate: 5 }}
        whileTap={{ rotate: -5 }}
        className="fixed z-50 cursor-pointer select-none"
        style={{
          width: size,
          height: size
        }}
      >
        {settings.petState === 'classic' ? (
          <motion.div
            variants={getAnimationVariants()}
            animate={currentAnimation}
            className="relative w-full h-full"
          >
            <img
              src={characterImage}
              alt={currentCharacter.name}
              className="w-full h-full object-contain drop-shadow-lg"
              draggable={false}
            />
          </motion.div>
        ) : (
          <motion.div
            className="relative w-full h-full"
            animate={{
              rotate: [0, -2, 2, 0],
              transition: { duration: 2, repeat: Infinity }
            }}
          >
            {/* Q萌心情帧动画 */}
            <div className="w-full h-full flex items-center justify-center">
              <img
                src={`/emoji/${currentMood.frames[currentFrame]}`}
                alt={currentMood.name}
                className="w-full h-full object-contain drop-shadow-lg"
                draggable={false}
              />
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* 右键菜单 */}
      {contextMenu && (
        <PetContextMenu
          position={contextMenu}
          onClose={handleCloseMenu}
          onOpenDialog={onOpenDialog}
          onOpenNotifications={onOpenNotifications}
          onOpenSettings={onOpenSettings}
          onExit={onExit}
          currentCharacter={settings.character}
          currentPetState={settings.petState}
          currentEmojiMood={settings.emojiMood}
          onStateChange={handleStateChange}
        />
      )}
    </>
  );
}