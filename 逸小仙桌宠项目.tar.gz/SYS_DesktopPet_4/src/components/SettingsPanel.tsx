import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Settings, 
  Volume2, 
  VolumeX, 
  User, 
  Palette, 
  Sliders,
  Monitor,
  Bell,
  Globe,
  Maximize2,
  Minimize2,
  ChevronRight,
  ChevronDown
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Slider } from './ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { usePetSettings } from '../hooks/usePetSettings';
import { useNotifications } from '../hooks/useNotifications';
import { useLayoutDetection, getPanelPosition } from '../hooks/useLayoutDetection';
import { dialogStyles, userModes } from '../data/characters';
import { UserProfile } from '../types';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsPanel({ isOpen, onClose }: SettingsPanelProps) {
  const { settings, updateSettings, resetSettings } = usePetSettings();
  const { requestNotificationPermission } = useNotifications();
  const layoutInfo = useLayoutDetection('settings');
  const [isExpanded, setIsExpanded] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    role: 'student',
    mode: 'counselor'
  });
  
  // 折叠式菜单状态
  const [expandedSections, setExpandedSections] = useState<{
    user: boolean;
    dialog: boolean;
    sound: boolean;
    display: boolean;
  }>({
    user: true,
    dialog: false,
    sound: false,
    display: false
  });

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const handleNotificationToggle = async (enabled: boolean) => {
    if (enabled) {
      await requestNotificationPermission();
    }
    updateSettings({ enableNotifications: enabled });
  };

  if (!isOpen) return null;

  // 计算面板位置和样式
  const petSize = settings.size === 'small' ? Math.round(60 * 1.3) : settings.size === 'large' ? Math.round(140 * 1.3) : Math.round(100 * 1.3);
  const position = getPanelPosition(settings.position, petSize, layoutInfo, 'settings');
  
  const getContainerStyle = () => {
    const baseStyle = {
      left: position.x,
      top: position.y,
    };

    switch (layoutInfo.mode) {
      case 'sidebar':
        return {
          ...baseStyle,
          width: 400,
          height: '100vh',
          maxWidth: 'none',
          maxHeight: 'none'
        };
      case 'compact':
        return {
          ...baseStyle,
          width: isExpanded ? 400 : 320,
          height: isExpanded ? 600 : 450,
          maxWidth: 'none',
          maxHeight: 'none'
        };
      default:
        return {
          width: '100%',
          maxWidth: '32rem', // max-w-2xl
          maxHeight: '80vh'
        };
    }
  };

  const containerStyle = getContainerStyle();
  const isCompact = layoutInfo.mode === 'compact' && !isExpanded;

  // 默认模式的内容
  const renderDefaultContent = () => (
    <>
      {/* 用户配置 */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <User className="w-5 h-5" />
          <h4>用户配置</h4>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>用户角色</Label>
            <Select
              value={userProfile.role}
              onValueChange={(value: 'student' | 'counselor' | 'parent') => 
                setUserProfile(prev => ({ ...prev, role: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="student">学生</SelectItem>
                <SelectItem value="counselor">辅导员</SelectItem>
                <SelectItem value="parent">家长</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>功能模式</Label>
            <Select
              value={userProfile.mode}
              onValueChange={(value: 'counselor' | 'recruitment' | 'wechat') => 
                setUserProfile(prev => ({ ...prev, mode: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="counselor">电子辅导员</SelectItem>
                <SelectItem value="recruitment">招生助手</SelectItem>
                <SelectItem value="wechat">公众号助手</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Card className="p-4 bg-muted/50">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <Globe className="w-4 h-4 text-primary-foreground" />
            </div>
            <div>
              <h5>{userModes[userProfile.mode].name}</h5>
              <p className="text-sm text-muted-foreground mt-1">
                {userModes[userProfile.mode].description}
              </p>
              <div className="flex flex-wrap gap-1 mt-2">
                {userModes[userProfile.mode].features.map((feature, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {feature}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </Card>
      </div>

      <Separator />

      {/* 对话设置 */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Palette className="w-5 h-5" />
          <h4>对话风格</h4>
        </div>
        
        <RadioGroup
          value={settings.dialogStyle}
          onValueChange={(value: 'warm' | 'passionate' | 'diligent') => 
            updateSettings({ dialogStyle: value })
          }
          className="space-y-3"
        >
          {Object.entries(dialogStyles).map(([key, style]) => (
            <div key={key} className="space-y-2">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value={key} id={key} />
                <Label htmlFor={key} className="font-medium">{style.name}</Label>
              </div>
              <p className="text-sm text-muted-foreground ml-6">
                {style.description}
              </p>
            </div>
          ))}
        </RadioGroup>
      </div>

      <Separator />

      {/* 声音设置 */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Volume2 className="w-5 h-5" />
          <h4>声音设置</h4>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>静音模式</Label>
              <p className="text-sm text-muted-foreground">
                关闭所有语音播放和提示音
              </p>
            </div>
            <Switch
              checked={settings.isMuted}
              onCheckedChange={(checked) => updateSettings({ isMuted: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>桌面通知</Label>
              <p className="text-sm text-muted-foreground">
                允许在桌面显示课程和作业提醒
              </p>
            </div>
            <Switch
              checked={settings.enableNotifications}
              onCheckedChange={handleNotificationToggle}
            />
          </div>
        </div>
      </div>

      <Separator />

      {/* 显示设置 */}
      <div className="space-y-4">
        <div className="flex items-center space-x-2">
          <Monitor className="w-5 h-5" />
          <h4>显示设置</h4>
        </div>
        
        <div className="space-y-6">
          <div className="space-y-2">
            <Label>桌宠大小</Label>
            <RadioGroup
              value={settings.size}
              onValueChange={(value: 'small' | 'medium' | 'large') => 
                updateSettings({ size: value })
              }
              className="flex space-x-6"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="small" id="small" />
                <Label htmlFor="small">小</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="medium" id="medium" />
                <Label htmlFor="medium">中</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="large" id="large" />
                <Label htmlFor="large">大</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>透明度: {Math.round(settings.transparency * 100)}%</Label>
            <Slider
              value={[settings.transparency]}
              onValueChange={([value]) => updateSettings({ transparency: value })}
              min={0.3}
              max={1}
              step={0.1}
              className="w-full"
            />
          </div>
        </div>
      </div>
    </>
  );

  // 紧凑模式的内容
  const renderCompactContent = () => (
    <>
      {/* 用户配置 - 折叠面板 */}
      <Collapsible open={expandedSections.user} onOpenChange={() => toggleSection('user')}>
        <CollapsibleTrigger className="flex items-center justify-between w-full p-2 hover:bg-muted rounded-lg">
          <div className="flex items-center space-x-2">
            <User className="w-4 h-4" />
            <span className="text-sm font-medium">用户配置</span>
          </div>
          {expandedSections.user ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-3 pt-2">
          <div className="space-y-2">
            <Label className="text-xs">用户角色</Label>
            <Select
              value={userProfile.role}
              onValueChange={(value: 'student' | 'counselor' | 'parent') => 
                setUserProfile(prev => ({ ...prev, role: value }))
              }
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="student">学生</SelectItem>
                <SelectItem value="counselor">辅导员</SelectItem>
                <SelectItem value="parent">家长</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-xs">功能模式</Label>
            <Select
              value={userProfile.mode}
              onValueChange={(value: 'counselor' | 'recruitment' | 'wechat') => 
                setUserProfile(prev => ({ ...prev, mode: value }))
              }
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="counselor">电子辅导员</SelectItem>
                <SelectItem value="recruitment">招生助手</SelectItem>
                <SelectItem value="wechat">公众号助手</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CollapsibleContent>
      </Collapsible>

      <Separator />
      
      {/* 对话风格 - 折叠面板 */}
      <Collapsible open={expandedSections.dialog} onOpenChange={() => toggleSection('dialog')}>
        <CollapsibleTrigger className="flex items-center justify-between w-full p-2 hover:bg-muted rounded-lg">
          <div className="flex items-center space-x-2">
            <Palette className="w-4 h-4" />
            <span className="text-sm font-medium">对话风格</span>
          </div>
          {expandedSections.dialog ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-2 pt-2">
          <RadioGroup
            value={settings.dialogStyle}
            onValueChange={(value: 'warm' | 'passionate' | 'diligent') => 
              updateSettings({ dialogStyle: value })
            }
            className="space-y-2"
          >
            {Object.entries(dialogStyles).map(([key, style]) => (
              <div key={key} className="flex items-center space-x-2">
                <RadioGroupItem value={key} id={key} />
                <Label htmlFor={key} className="text-xs">{style.name}</Label>
              </div>
            ))}
          </RadioGroup>
        </CollapsibleContent>
      </Collapsible>

      <Separator />

      {/* 声音设置 - 折叠面板 */}
      <Collapsible open={expandedSections.sound} onOpenChange={() => toggleSection('sound')}>
        <CollapsibleTrigger className="flex items-center justify-between w-full p-2 hover:bg-muted rounded-lg">
          <div className="flex items-center space-x-2">
            <Volume2 className="w-4 h-4" />
            <span className="text-sm font-medium">声音设置</span>
          </div>
          {expandedSections.sound ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <Label className="text-xs">静音模式</Label>
            <Switch
              checked={settings.isMuted}
              onCheckedChange={(checked) => updateSettings({ isMuted: checked })}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label className="text-xs">桌面通知</Label>
            <Switch
              checked={settings.enableNotifications}
              onCheckedChange={handleNotificationToggle}
            />
          </div>
        </CollapsibleContent>
      </Collapsible>

      <Separator />

      {/* 显示设置 - 折叠面板 */}
      <Collapsible open={expandedSections.display} onOpenChange={() => toggleSection('display')}>
        <CollapsibleTrigger className="flex items-center justify-between w-full p-2 hover:bg-muted rounded-lg">
          <div className="flex items-center space-x-2">
            <Monitor className="w-4 h-4" />
            <span className="text-sm font-medium">显示设置</span>
          </div>
          {expandedSections.display ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-3 pt-2">
          <div className="space-y-2">
            <Label className="text-xs">桌宠大小</Label>
            <RadioGroup
              value={settings.size}
              onValueChange={(value: 'small' | 'medium' | 'large') => 
                updateSettings({ size: value })
              }
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="small" id="small-compact" />
                <Label htmlFor="small-compact" className="text-xs">小</Label>
              </div>
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="medium" id="medium-compact" />
                <Label htmlFor="medium-compact" className="text-xs">中</Label>
              </div>
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="large" id="large-compact" />
                <Label htmlFor="large-compact" className="text-xs">大</Label>
              </div>
            </RadioGroup>
          </div>
          <div className="space-y-2">
            <Label className="text-xs">透明度: {Math.round(settings.transparency * 100)}%</Label>
            <Slider
              value={[settings.transparency]}
              onValueChange={([value]) => updateSettings({ transparency: value })}
              min={0.3}
              max={1}
              step={0.1}
              className="w-full"
            />
          </div>
        </CollapsibleContent>
      </Collapsible>
    </>
  );

  if (layoutInfo.mode === 'default') {
    return (
      <AnimatePresence>
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="w-full max-w-2xl max-h-[80vh] flex flex-col"
          >
            <Card className="flex-1 flex flex-col shadow-xl overflow-hidden">
              {/* 标题栏 */}
              <div className="flex items-center justify-between p-3 sm:p-6 border-b">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <Settings className="w-4 h-4 text-primary-foreground" />
                  </div>
                  <div>
                    <h3>桌宠设置</h3>
                    <p className="text-sm text-muted-foreground">
                      个性化您的桌宠体验
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClose}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* 设置内容 */}
              <div className="flex-1 overflow-y-auto p-3 sm:p-6 space-y-4 sm:space-y-8">
                {renderDefaultContent()}
              </div>

              <Separator />

              {/* 底部操作 */}
              <div className="p-3 sm:p-6 border-t">
                <div className="flex items-center justify-between">
                  <Button
                    variant="outline"
                    onClick={resetSettings}
                  >
                    恢复默认
                  </Button>
                  <Button onClick={onClose}>
                    保存设置
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </AnimatePresence>
    );
  }

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-40 bg-transparent"
        onClick={onClose}
      />
      <motion.div
        initial={{ opacity: 0, x: layoutInfo.position === 'right' ? 50 : -50 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: layoutInfo.position === 'right' ? 50 : -50 }}
        className="fixed z-50 flex flex-col"
        style={containerStyle}
      >
        <Card className="flex-1 flex flex-col shadow-xl overflow-hidden">
          {/* 标题栏 */}
          <div className="flex items-center justify-between p-3 sm:p-6 border-b">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Settings className="w-4 h-4 text-primary-foreground" />
              </div>
              {!isCompact ? (
                <div>
                  <h3>桌宠设置</h3>
                  <p className="text-sm text-muted-foreground">
                    个性化您的桌宠体验
                  </p>
                </div>
              ) : (
                <div className="text-sm font-medium">设置</div>
              )}
            </div>
            <div className="flex items-center space-x-1">
              {layoutInfo.mode === 'compact' && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsExpanded(!isExpanded)}
                >
                  {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* 设置内容 */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-6 space-y-4 sm:space-y-8">
            {isCompact ? renderCompactContent() : renderDefaultContent()}
          </div>

          <Separator />

          {/* 底部操作 */}
          <div className="p-3 sm:p-6 border-t">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                size={isCompact ? "sm" : "default"}
                onClick={resetSettings}
                className={isCompact ? "text-xs" : ""}
              >
                恢复默认
              </Button>
              <Button 
                onClick={onClose} 
                size={isCompact ? "sm" : "default"}
                className={isCompact ? "text-xs" : ""}
              >
                保存设置
              </Button>
            </div>
          </div>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}