import React from 'react';
import { Card } from './ui/card';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Input } from './ui/input';
import { Keyframe } from './Timeline';

interface KeyframePanelProps {
  selectedKeyframe?: Keyframe;
  onUpdateKeyframe: (keyframeId: string, properties: Partial<Keyframe['properties']>) => void;
}

export function KeyframePanel({ selectedKeyframe, onUpdateKeyframe }: KeyframePanelProps) {
  if (!selectedKeyframe) {
    return (
      <Card className="p-6">
        <h3 className="mb-4">关键帧属性</h3>
        <p className="text-muted-foreground text-center">
          选择一个关键帧来编辑属性
        </p>
      </Card>
    );
  }

  const handlePropertyChange = (property: keyof Keyframe['properties'], value: number) => {
    onUpdateKeyframe(selectedKeyframe.id, {
      [property]: value
    });
  };

  const { properties } = selectedKeyframe;

  return (
    <Card className="p-6 space-y-6">
      <h3>关键帧属性</h3>
      
      <div className="space-y-4">
        <div className="text-sm text-muted-foreground">
          时间: {selectedKeyframe.time.toFixed(2)}秒
        </div>

        {/* 位置 X */}
        <div className="space-y-2">
          <Label>位置 X</Label>
          <div className="flex items-center space-x-3">
            <Slider
              value={[properties.x]}
              min={-500}
              max={500}
              step={1}
              onValueChange={([value]) => handlePropertyChange('x', value)}
              className="flex-1"
            />
            <Input
              type="number"
              value={properties.x}
              onChange={(e) => handlePropertyChange('x', Number(e.target.value))}
              className="w-20"
              min={-500}
              max={500}
            />
          </div>
        </div>

        {/* 位置 Y */}
        <div className="space-y-2">
          <Label>位置 Y</Label>
          <div className="flex items-center space-x-3">
            <Slider
              value={[properties.y]}
              min={-500}
              max={500}
              step={1}
              onValueChange={([value]) => handlePropertyChange('y', value)}
              className="flex-1"
            />
            <Input
              type="number"
              value={properties.y}
              onChange={(e) => handlePropertyChange('y', Number(e.target.value))}
              className="w-20"
              min={-500}
              max={500}
            />
          </div>
        </div>

        {/* 缩放 */}
        <div className="space-y-2">
          <Label>缩放</Label>
          <div className="flex items-center space-x-3">
            <Slider
              value={[properties.scale]}
              min={0.1}
              max={3}
              step={0.1}
              onValueChange={([value]) => handlePropertyChange('scale', value)}
              className="flex-1"
            />
            <Input
              type="number"
              value={properties.scale}
              onChange={(e) => handlePropertyChange('scale', Number(e.target.value))}
              className="w-20"
              min={0.1}
              max={3}
              step={0.1}
            />
          </div>
        </div>

        {/* 旋转 */}
        <div className="space-y-2">
          <Label>旋转角度</Label>
          <div className="flex items-center space-x-3">
            <Slider
              value={[properties.rotation]}
              min={-360}
              max={360}
              step={1}
              onValueChange={([value]) => handlePropertyChange('rotation', value)}
              className="flex-1"
            />
            <Input
              type="number"
              value={properties.rotation}
              onChange={(e) => handlePropertyChange('rotation', Number(e.target.value))}
              className="w-20"
              min={-360}
              max={360}
            />
          </div>
        </div>

        {/* 透明度 */}
        <div className="space-y-2">
          <Label>透明度</Label>
          <div className="flex items-center space-x-3">
            <Slider
              value={[properties.opacity]}
              min={0}
              max={1}
              step={0.01}
              onValueChange={([value]) => handlePropertyChange('opacity', value)}
              className="flex-1"
            />
            <Input
              type="number"
              value={properties.opacity}
              onChange={(e) => handlePropertyChange('opacity', Number(e.target.value))}
              className="w-20"
              min={0}
              max={1}
              step={0.01}
            />
          </div>
        </div>
      </div>

      {/* 属性值预览 */}
      <div className="pt-4 border-t space-y-2">
        <h4 className="text-sm">当前属性值</h4>
        <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
          <div>X: {properties.x}px</div>
          <div>Y: {properties.y}px</div>
          <div>缩放: {properties.scale.toFixed(2)}</div>
          <div>旋转: {properties.rotation}°</div>
          <div>透明度: {(properties.opacity * 100).toFixed(0)}%</div>
        </div>
      </div>
    </Card>
  );
}