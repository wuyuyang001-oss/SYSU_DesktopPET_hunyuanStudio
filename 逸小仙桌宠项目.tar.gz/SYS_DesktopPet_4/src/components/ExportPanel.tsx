import React, { useState } from 'react';
import { Download, Copy, Check, FileJson } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner@2.0.3';
import { Keyframe } from './Timeline';

interface ExportData {
  name: string;
  duration: number;
  keyframes: Keyframe[];
  metadata: {
    version: string;
    createdAt: string;
    frameRate: number;
    resolution: {
      width: number;
      height: number;
    };
  };
}

interface ExportPanelProps {
  keyframes: Keyframe[];
  duration: number;
  imageName?: string;
}

export function ExportPanel({ keyframes, duration, imageName }: ExportPanelProps) {
  const [animationName, setAnimationName] = useState(imageName || '桌宠动画');
  const [copied, setCopied] = useState(false);

  const generateExportData = (): ExportData => {
    return {
      name: animationName,
      duration,
      keyframes: keyframes.map(kf => ({
        ...kf,
        properties: { ...kf.properties }
      })),
      metadata: {
        version: '1.0.0',
        createdAt: new Date().toISOString(),
        frameRate: 60,
        resolution: {
          width: 800,
          height: 600
        },
        character: '商务小人桌宠',
        animationType: 'desktop_pet',
        format: 'json'
      }
    };
  };

  const exportData = generateExportData();
  const jsonString = JSON.stringify(exportData, null, 2);

  const handleDownload = () => {
    if (keyframes.length === 0) {
      toast.error('没有关键帧数据可导出');
      return;
    }

    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${animationName}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    toast.success('动画文件已下载');
  };

  const handleCopyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(jsonString);
      setCopied(true);
      toast.success('JSON数据已复制到剪贴板');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast.error('复制失败，请手动复制');
    }
  };

  const formatFileSize = (jsonStr: string) => {
    const size = new Blob([jsonStr]).size;
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <Card className="p-6 space-y-6">
      <div className="flex items-center space-x-2">
        <FileJson className="w-5 h-5" />
        <h3>导出动画</h3>
      </div>

      {/* 动画信息 */}
      <div className="space-y-4">
        <div>
          <Label htmlFor="animation-name">动画名称</Label>
          <Input
            id="animation-name"
            value={animationName}
            onChange={(e) => setAnimationName(e.target.value)}
            placeholder="输入动画名称"
          />
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="space-y-1">
            <span className="text-muted-foreground">时长</span>
            <div>{duration.toFixed(2)} 秒</div>
          </div>
          <div className="space-y-1">
            <span className="text-muted-foreground">关键帧数量</span>
            <div>{keyframes.length} 个</div>
          </div>
          <div className="space-y-1">
            <span className="text-muted-foreground">文件大小</span>
            <div>{formatFileSize(jsonString)}</div>
          </div>
          <div className="space-y-1">
            <span className="text-muted-foreground">格式版本</span>
            <div>v1.0.0</div>
          </div>
        </div>
      </div>

      {/* 导出按钮 */}
      <div className="flex space-x-2">
        <Button 
          onClick={handleDownload}
          disabled={keyframes.length === 0}
          className="flex-1"
        >
          <Download className="w-4 h-4 mr-2" />
          下载 JSON 文件
        </Button>
        <Button 
          variant="outline" 
          onClick={handleCopyToClipboard}
          disabled={keyframes.length === 0}
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        </Button>
      </div>

      {/* JSON 预览 */}
      {keyframes.length > 0 ? (
        <div className="space-y-2">
          <Label>JSON 预览</Label>
          <Textarea
            value={jsonString}
            readOnly
            className="font-mono text-xs h-48 resize-none"
            placeholder="动画数据将在这里显示..."
          />
        </div>
      ) : (
        <div className="p-8 bg-muted rounded-lg text-center">
          <FileJson className="w-12 h-12 mx-auto mb-2 text-muted-foreground" />
          <p className="text-muted-foreground">
            添加关键帧后可以导出动画数据
          </p>
        </div>
      )}

      {/* 使用说明 */}
      <div className="space-y-2 text-sm text-muted-foreground">
        <h4>桌宠动画格式</h4>
        <ul className="space-y-1 list-disc list-inside">
          <li>标准JSON格式，兼容主流桌宠软件</li>
          <li>包含完整的时间轴和关键帧数据</li>
          <li>支持位置、缩放、旋转、透明度动画</li>
          <li>包含角色信息和动画元数据</li>
          <li>60fps流畅动画，适合桌面显示</li>
        </ul>
      </div>
    </Card>
  );
}