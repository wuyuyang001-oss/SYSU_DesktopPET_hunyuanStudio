import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Keyframe } from './Timeline';

interface AnimationPreviewProps {
  imageUrl: string;
  keyframes: Keyframe[];
  currentTime: number;
  isPlaying: boolean;
  duration: number;
}

export function AnimationPreview({
  imageUrl,
  keyframes,
  currentTime,
  isPlaying,
  duration
}: AnimationPreviewProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // 根据当前时间插值计算属性值
  const getCurrentProperties = () => {
    if (keyframes.length === 0) {
      return {
        x: 0,
        y: 0,
        scale: 1,
        rotation: 0,
        opacity: 1
      };
    }

    // 如果只有一个关键帧，直接返回其属性
    if (keyframes.length === 1) {
      return keyframes[0].properties;
    }

    // 找到当前时间前后的关键帧
    const sortedKeyframes = [...keyframes].sort((a, b) => a.time - b.time);
    
    // 如果当前时间在第一个关键帧之前
    if (currentTime <= sortedKeyframes[0].time) {
      return sortedKeyframes[0].properties;
    }

    // 如果当前时间在最后一个关键帧之后
    if (currentTime >= sortedKeyframes[sortedKeyframes.length - 1].time) {
      return sortedKeyframes[sortedKeyframes.length - 1].properties;
    }

    // 找到当前时间所在的关键帧区间
    let prevKeyframe = sortedKeyframes[0];
    let nextKeyframe = sortedKeyframes[1];

    for (let i = 0; i < sortedKeyframes.length - 1; i++) {
      if (currentTime >= sortedKeyframes[i].time && currentTime <= sortedKeyframes[i + 1].time) {
        prevKeyframe = sortedKeyframes[i];
        nextKeyframe = sortedKeyframes[i + 1];
        break;
      }
    }

    // 计算插值比例
    const timeDiff = nextKeyframe.time - prevKeyframe.time;
    const progress = timeDiff === 0 ? 0 : (currentTime - prevKeyframe.time) / timeDiff;

    // 对每个属性进行线性插值
    const interpolate = (start: number, end: number, progress: number) => {
      return start + (end - start) * progress;
    };

    return {
      x: interpolate(prevKeyframe.properties.x, nextKeyframe.properties.x, progress),
      y: interpolate(prevKeyframe.properties.y, nextKeyframe.properties.y, progress),
      scale: interpolate(prevKeyframe.properties.scale, nextKeyframe.properties.scale, progress),
      rotation: interpolate(prevKeyframe.properties.rotation, nextKeyframe.properties.rotation, progress),
      opacity: interpolate(prevKeyframe.properties.opacity, nextKeyframe.properties.opacity, progress)
    };
  };

  const currentProperties = getCurrentProperties();

  if (!imageUrl) {
    return (
      <Card className="p-6 h-96 flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <div className="w-16 h-16 bg-muted rounded-lg mx-auto mb-4 flex items-center justify-center">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
          <p>上传图片后可以预览动画效果</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h3 className="mb-4">动画预览</h3>
      
      <div 
        ref={containerRef}
        className="relative h-96 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 rounded-lg overflow-hidden border"
      >
        {/* 中心线标记 */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-px h-full bg-border opacity-30" />
          <div className="absolute w-full h-px bg-border opacity-30" />
        </div>

        {/* 动画元素 */}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{
              x: currentProperties.x,
              y: currentProperties.y,
              scale: currentProperties.scale,
              rotate: currentProperties.rotation,
              opacity: currentProperties.opacity
            }}
            transition={{
              duration: 0.1,
              ease: "linear"
            }}
            className="relative"
          >
            <img
              src={imageUrl}
              alt="桌宠"
              className="w-20 h-20 object-contain pointer-events-none select-none drop-shadow-lg"
              draggable={false}
            />
          </motion.div>
        </div>

        {/* 状态指示器 */}
        <div className="absolute top-4 left-4 space-y-1">
          <div className="text-xs bg-black/50 text-white px-2 py-1 rounded">
            时间: {currentTime.toFixed(2)}s
          </div>
          <div className="text-xs bg-black/50 text-white px-2 py-1 rounded">
            {isPlaying ? '播放中' : '暂停'}
          </div>
        </div>

        {/* 属性显示 */}
        <div className="absolute bottom-4 right-4 space-y-1">
          <div className="text-xs bg-black/50 text-white px-2 py-1 rounded">
            位置: ({currentProperties.x.toFixed(0)}, {currentProperties.y.toFixed(0)})
          </div>
          <div className="text-xs bg-black/50 text-white px-2 py-1 rounded">
            缩放: {currentProperties.scale.toFixed(2)} | 旋转: {currentProperties.rotation.toFixed(0)}°
          </div>
          <div className="text-xs bg-black/50 text-white px-2 py-1 rounded">
            透明度: {(currentProperties.opacity * 100).toFixed(0)}%
          </div>
        </div>
      </div>

      {keyframes.length === 0 && (
        <div className="mt-4 p-4 bg-muted rounded-lg">
          <p className="text-sm text-muted-foreground text-center">
            添加关键帧开始制作动画
          </p>
        </div>
      )}
    </Card>
  );
}