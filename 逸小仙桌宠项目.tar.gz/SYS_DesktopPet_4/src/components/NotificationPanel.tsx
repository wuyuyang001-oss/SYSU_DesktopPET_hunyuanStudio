import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Bell, 
  Clock, 
  BookOpen, 
  FileText, 
  Users, 
  ExternalLink,
  CheckCircle,
  Circle,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { useNotifications } from '../hooks/useNotifications';
import { usePetSettings } from '../hooks/usePetSettings';
import { useLayoutDetection, getPanelPosition } from '../hooks/useLayoutDetection';
import { NotificationItem } from '../types';

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NotificationPanel({ isOpen, onClose }: NotificationPanelProps) {
  const { settings } = usePetSettings();
  const layoutInfo = useLayoutDetection('notification');
  const [isExpanded, setIsExpanded] = useState(false);
  const { 
    notifications, 
    unreadCount, 
    markAsRead, 
    markAllAsRead, 
    removeNotification 
  } = useNotifications();

  const getNotificationIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'course':
        return <BookOpen className="w-4 h-4" />;
      case 'assignment':
        return <FileText className="w-4 h-4" />;
      case 'meeting':
        return <Users className="w-4 h-4" />;
      case 'reminder':
        return <Clock className="w-4 h-4" />;
      default:
        return <Bell className="w-4 h-4" />;
    }
  };

  const getNotificationColor = (type: NotificationItem['type']) => {
    switch (type) {
      case 'course':
        return 'bg-blue-500';
      case 'assignment':
        return 'bg-orange-500';
      case 'meeting':
        return 'bg-green-500';
      case 'reminder':
        return 'bg-purple-500';
      default:
        return 'bg-gray-500';
    }
  };

  const formatTimeRemaining = (time: Date) => {
    const now = new Date();
    const diff = time.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    if (diff < 0) {
      return '已过期';
    } else if (hours > 0) {
      return `${hours}小时${minutes}分钟后`;
    } else if (minutes > 0) {
      return `${minutes}分钟后`;
    } else {
      return '即将开始';
    }
  };

  const handleNotificationClick = (notification: NotificationItem) => {
    markAsRead(notification.id);
    if (notification.url) {
      window.open(notification.url, '_blank');
    }
  };

  if (!isOpen) return null;

  // 计算面板位置和样式
  const petSize = settings.size === 'small' ? 60 : settings.size === 'large' ? 140 : 100;
  const position = getPanelPosition(settings.position, petSize, layoutInfo, 'notification');
  
  const getContainerStyle = () => {
    const baseStyle = {
      left: position.x,
      top: position.y,
    };

    switch (layoutInfo.mode) {
      case 'sidebar':
        return {
          ...baseStyle,
          width: 400,
          height: '100vh',
          maxWidth: 'none',
          maxHeight: 'none'
        };
      case 'compact':
        return {
          ...baseStyle,
          width: isExpanded ? 384 : 280,
          height: isExpanded ? 500 : 350,
          maxWidth: 'none',
          maxHeight: 'none'
        };
      default:
        return {
          width: '100%',
          maxWidth: '24rem', // max-w-md
          height: '500px'
        };
    }
  };

  const containerStyle = getContainerStyle();

  return (
    <AnimatePresence>
      {layoutInfo.mode === 'default' ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="w-full max-w-md h-[500px] flex flex-col"
          >
            <Card className="flex-1 flex flex-col shadow-xl">
              {/* 标题栏 */}
              <div className="flex items-center justify-between p-2 sm:p-4 border-b">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Bell className="w-4 h-4 text-primary-foreground" />
                </div>
                {layoutInfo.mode !== 'compact' || isExpanded ? (
                  <div>
                    <h3>今日待办</h3>
                    <p className="text-sm text-muted-foreground">
                      {unreadCount > 0 ? `${unreadCount}个未读通知` : '暂无未读通知'}
                    </p>
                  </div>
                ) : (
                  <div>
                    <div className="text-sm font-medium">待办</div>
                    {unreadCount > 0 && (
                      <Badge variant="destructive" className="text-xs h-4 px-1">
                        {unreadCount}
                      </Badge>
                    )}
                  </div>
                )}
              </div>
              <div className="flex items-center space-x-1">
                {layoutInfo.mode === 'compact' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsExpanded(!isExpanded)}
                  >
                    {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                  </Button>
                )}
                {unreadCount > 0 && (layoutInfo.mode !== 'compact' || isExpanded) && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={markAllAsRead}
                  >
                    全部已读
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* 通知列表 */}
            <ScrollArea className="flex-1">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full p-4 sm:p-8 text-center">
                  <Bell className="w-8 h-8 sm:w-12 sm:h-12 text-muted-foreground mb-4" />
                  {layoutInfo.mode !== 'compact' || isExpanded ? (
                    <>
                      <h4 className="mb-2">暂无通知</h4>
                      <p className="text-sm text-muted-foreground">
                        当有新的课程或作业安排时，会在这里显示
                      </p>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground">暂无通知</p>
                  )}
                </div>
              ) : (
                <div className="p-2 sm:p-4 space-y-2 sm:space-y-3">
                  {notifications.map((notification) => (
                    <motion.div
                      key={notification.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                    >
                      <Card 
                        className={`p-2 sm:p-4 cursor-pointer transition-all hover:shadow-md ${
                          !notification.isRead ? 'ring-2 ring-primary/20' : ''
                        }`}
                        onClick={() => handleNotificationClick(notification)}
                      >
                        <div className="flex items-start space-x-2 sm:space-x-3">
                          {/* 图标 */}
                          <div className={`p-1.5 sm:p-2 rounded-full ${getNotificationColor(notification.type)} text-white flex-shrink-0`}>
                            {getNotificationIcon(notification.type)}
                          </div>

                          {/* 内容 */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className={`font-medium ${layoutInfo.mode === 'compact' && !isExpanded ? 'text-sm' : ''}`}>
                                  {notification.title}
                                </h4>
                                {(layoutInfo.mode !== 'compact' || isExpanded) && (
                                  <p className="text-sm text-muted-foreground mt-1">
                                    {notification.content}
                                  </p>
                                )}
                              </div>
                              
                              {/* 状态图标 */}
                              <div className="ml-2 flex-shrink-0">
                                {notification.isRead ? (
                                  <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground" />
                                ) : (
                                  <Circle className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                                )}
                              </div>
                            </div>

                            {/* 时间和链接 */}
                            <div className={`flex items-center ${layoutInfo.mode === 'compact' && !isExpanded ? 'justify-start' : 'justify-between'} mt-2 sm:mt-3`}>
                              <div className="flex items-center space-x-1 sm:space-x-2">
                                <Badge variant="outline" className="text-xs">
                                  <Clock className="w-3 h-3 mr-1" />
                                  {formatTimeRemaining(notification.time)}
                                </Badge>
                                {(layoutInfo.mode !== 'compact' || isExpanded) && (
                                  <span className="text-xs text-muted-foreground">
                                    {notification.time.toLocaleDateString()} {notification.time.toLocaleTimeString().slice(0, 5)}
                                  </span>
                                )}
                              </div>
                              
                              {notification.url && (layoutInfo.mode !== 'compact' || isExpanded) && (
                                <ExternalLink className="w-4 h-4 text-muted-foreground" />
                              )}
                            </div>
                          </div>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              )}
            </ScrollArea>

            <Separator />

            {/* 底部操作 */}
            {(layoutInfo.mode !== 'compact' || isExpanded) && (
              <div className="p-2 sm:p-4">
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>关联学工平台</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open('https://platform.edu.cn', '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-1" />
                    访问平台
                  </Button>
                </div>
              </div>
            )}
            </Card>
          </motion.div>
        </div>
      ) : (
        <>
          <div 
            className="fixed inset-0 z-40 bg-transparent"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, x: layoutInfo.position === 'right' ? 50 : -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: layoutInfo.position === 'right' ? 50 : -50 }}
            className="fixed z-50 flex flex-col"
            style={containerStyle}
          >
            <Card className="flex-1 flex flex-col shadow-xl">
              {/* Duplicate the content for sidebar/compact mode */}
              <div className="flex items-center justify-between p-2 sm:p-4 border-b">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <Bell className="w-4 h-4 text-primary-foreground" />
                  </div>
                  {layoutInfo.mode !== 'compact' || isExpanded ? (
                    <div>
                      <h3>今日待办</h3>
                      <p className="text-sm text-muted-foreground">
                        {unreadCount > 0 ? `${unreadCount}个未读通知` : '暂无未读通知'}
                      </p>
                    </div>
                  ) : (
                    <div>
                      <div className="text-sm font-medium">待办</div>
                      {unreadCount > 0 && (
                        <Badge variant="destructive" className="text-xs h-4 px-1">
                          {unreadCount}
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
                <div className="flex items-center space-x-1">
                  {layoutInfo.mode === 'compact' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsExpanded(!isExpanded)}
                    >
                      {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                    </Button>
                  )}
                  {unreadCount > 0 && (layoutInfo.mode !== 'compact' || isExpanded) && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={markAllAsRead}
                    >
                      全部已读
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClose}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* 通知列表 */}
              <ScrollArea className="flex-1">
                {notifications.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full p-4 sm:p-8 text-center">
                    <Bell className="w-8 h-8 sm:w-12 sm:h-12 text-muted-foreground mb-4" />
                    {layoutInfo.mode !== 'compact' || isExpanded ? (
                      <>
                        <h4 className="mb-2">暂无通知</h4>
                        <p className="text-sm text-muted-foreground">
                          当有新的课程或作业安排时，会在这里显示
                        </p>
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground">暂无通知</p>
                    )}
                  </div>
                ) : (
                  <div className="p-2 sm:p-4 space-y-2 sm:space-y-3">
                    {notifications.map((notification) => (
                      <Card 
                        key={notification.id}
                        className={`p-2 sm:p-4 cursor-pointer transition-all hover:shadow-md ${
                          !notification.isRead ? 'ring-2 ring-primary/20' : ''
                        }`}
                        onClick={() => handleNotificationClick(notification)}
                      >
                        <div className="flex items-start space-x-2 sm:space-x-3">
                          {/* 图标 */}
                          <div className={`p-1.5 sm:p-2 rounded-full ${getNotificationColor(notification.type)} text-white flex-shrink-0`}>
                            {getNotificationIcon(notification.type)}
                          </div>

                          {/* 内容 */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className={`font-medium ${layoutInfo.mode === 'compact' && !isExpanded ? 'text-sm' : ''}`}>
                                  {notification.title}
                                </h4>
                                {(layoutInfo.mode !== 'compact' || isExpanded) && (
                                  <p className="text-sm text-muted-foreground mt-1">
                                    {notification.content}
                                  </p>
                                )}
                              </div>
                              
                              {/* 状态图标 */}
                              <div className="ml-2 flex-shrink-0">
                                {notification.isRead ? (
                                  <CheckCircle className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground" />
                                ) : (
                                  <Circle className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                                )}
                              </div>
                            </div>

                            {/* 时间和链接 */}
                            <div className={`flex items-center ${layoutInfo.mode === 'compact' && !isExpanded ? 'justify-start' : 'justify-between'} mt-2 sm:mt-3`}>
                              <div className="flex items-center space-x-1 sm:space-x-2">
                                <Badge variant="outline" className="text-xs">
                                  <Clock className="w-3 h-3 mr-1" />
                                  {formatTimeRemaining(notification.time)}
                                </Badge>
                                {(layoutInfo.mode !== 'compact' || isExpanded) && (
                                  <span className="text-xs text-muted-foreground">
                                    {notification.time.toLocaleDateString()} {notification.time.toLocaleTimeString().slice(0, 5)}
                                  </span>
                                )}
                              </div>
                              
                              {notification.url && (layoutInfo.mode !== 'compact' || isExpanded) && (
                                <ExternalLink className="w-4 h-4 text-muted-foreground" />
                              )}
                            </div>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </ScrollArea>

              {/* 底部操作 */}
              {(layoutInfo.mode !== 'compact' || isExpanded) && (
                <div className="p-2 sm:p-4">
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>关联学工平台</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open('https://platform.edu.cn', '_blank')}
                    >
                      <ExternalLink className="w-4 h-4 mr-1" />
                      访问平台
                    </Button>
                  </div>
                </div>
              )}
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}