import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageCircle, 
  Bell, 
  Settings, 
  LogOut, 
  ChevronRight,
  User
} from 'lucide-react';
import { petStates, emojiMoods } from '../data/characters';
import { Card } from './ui/card';
import { Separator } from './ui/separator';

interface PetContextMenuProps {
  position: { x: number; y: number };
  onClose: () => void;
  onOpenDialog: () => void;
  onOpenNotifications: () => void;
  onOpenSettings: () => void;
  onExit: () => void;
  currentCharacter: string;
  currentPetState: 'classic' | 'emoji';
  currentEmojiMood: 'humming' | 'love' | 'laugh' | 'annoy' | 'destress' | 'good';
  onStateChange: (state: 'classic' | 'emoji', mood?: 'humming' | 'love' | 'laugh' | 'annoy' | 'destress' | 'good') => void;
}

export function PetContextMenu({
  position,
  onClose,
  onOpenDialog,
  onOpenNotifications,
  onOpenSettings,
  onExit,
  currentCharacter,
  currentPetState,
  currentEmojiMood,
  onStateChange
}: PetContextMenuProps) {
  const [showStateMenu, setShowStateMenu] = React.useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [onClose]);

  // 调整菜单位置以确保不超出屏幕
  const adjustedPosition = {
    x: Math.min(position.x, window.innerWidth - 250),
    y: Math.min(position.y, window.innerHeight - 300)
  };

  const currentState = petStates.find(s => s.id === currentPetState);
  const currentMood = emojiMoods.find(m => m.id === currentEmojiMood);

  const getCharacterIcon = (characterId: string) => {
    return <User className="w-4 h-4" />;
  };

  return (
    <div className="fixed inset-0 z-50">
      <motion.div
        ref={menuRef}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.1 }}
        className="absolute"
        style={{
          left: adjustedPosition.x,
          top: adjustedPosition.y
        }}
      >
        <Card className="min-w-48 p-2 shadow-lg border">
          {/* 主菜单 */}
          <div className="space-y-1">
            {/* 切换状态 */}
            <div className="relative">
              <button
                onMouseEnter={() => setShowStateMenu(true)}
                onMouseLeave={() => setShowStateMenu(false)}
                className="w-full flex items-center justify-between px-3 py-2 text-sm rounded-md hover:bg-muted transition-colors"
              >
                <div className="flex items-center space-x-2">
                  {currentPetState === 'emoji' ? (
                    <span className="text-base">{currentMood?.emoji}</span>
                  ) : (
                    getCharacterIcon(currentCharacter)
                  )}
                  <span>切换状态</span>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>

              {/* 状态选择子菜单 */}
              <AnimatePresence>
                {showStateMenu && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ duration: 0.1 }}
                    className="absolute left-full top-0 ml-1"
                    onMouseEnter={() => setShowStateMenu(true)}
                    onMouseLeave={() => setShowStateMenu(false)}
                  >
                    <Card className="min-w-52 shadow-lg border">
                      <div className="max-h-96 overflow-y-auto p-2 space-y-1">
                        {/* 经典原像 */}
                        <div className="space-y-1">
                          <div className="px-2 py-1 text-xs text-muted-foreground sticky top-0 bg-card z-10">桌宠状态</div>
                          <button
                            onClick={() => {
                              onStateChange('classic');
                              onClose();
                            }}
                            className={`w-full flex items-center space-x-2 px-3 py-2 text-sm rounded-md hover:bg-muted transition-colors ${
                              currentPetState === 'classic' ? 'bg-muted' : ''
                            }`}
                          >
                            {getCharacterIcon(currentCharacter)}
                            <span>{petStates[0].name}</span>
                          </button>
                        </div>

                        <Separator className="my-2" />

                        {/* Q萌心情 */}
                        <div className="space-y-1">
                          <div className="px-2 py-1 text-xs text-muted-foreground sticky top-0 bg-card z-10">Q萌心情</div>
                          {emojiMoods.map(mood => (
                            <button
                              key={mood.id}
                              onClick={() => {
                                onStateChange('emoji', mood.id);
                                onClose();
                              }}
                              className={`w-full flex items-center space-x-2 px-3 py-2 text-sm rounded-md hover:bg-muted transition-colors ${
                                currentPetState === 'emoji' && currentEmojiMood === mood.id ? 'bg-muted' : ''
                              }`}
                            >
                              <span className="text-base">{mood.emoji}</span>
                              <span>{mood.name}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 打开对话 */}
            <button
              onClick={() => {
                onOpenDialog();
                onClose();
              }}
              className="w-full flex items-center space-x-2 px-3 py-2 text-sm rounded-md hover:bg-muted transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>打开对话</span>
            </button>

            {/* 查看通知 */}
            <button
              onClick={() => {
                onOpenNotifications();
                onClose();
              }}
              className="w-full flex items-center space-x-2 px-3 py-2 text-sm rounded-md hover:bg-muted transition-colors"
            >
              <Bell className="w-4 h-4" />
              <span>查看通知</span>
            </button>

            {/* 设置 */}
            <button
              onClick={() => {
                onOpenSettings();
                onClose();
              }}
              className="w-full flex items-center space-x-2 px-3 py-2 text-sm rounded-md hover:bg-muted transition-colors"
            >
              <Settings className="w-4 h-4" />
              <span>设置</span>
            </button>

            <Separator className="my-1" />

            {/* 退出桌宠 */}
            <button
              onClick={() => {
                onExit();
                onClose();
              }}
              className="w-full flex items-center space-x-2 px-3 py-2 text-sm rounded-md hover:bg-destructive hover:text-destructive-foreground transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>退出桌宠</span>
            </button>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}