import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Clock, Zap, Heart, Brain, Eye } from 'lucide-react';

export function AnimationGuide() {
  const animations = [
    {
      name: '待机摇摆',
      description: '轻微的左右摇摆，让桌宠看起来活泼可爱',
      duration: '4秒',
      icon: <Clock className="w-4 h-4" />,
      color: 'bg-blue-500'
    },
    {
      name: '挥手问候',
      description: '友好的挥手动作，适合问候场景',
      duration: '3秒',
      icon: <Heart className="w-4 h-4" />,
      color: 'bg-green-500'
    },
    {
      name: '开心跳跃',
      description: '兴奋的跳跃动作，表达开心的情绪',
      duration: '2秒',
      icon: <Zap className="w-4 h-4" />,
      color: 'bg-yellow-500'
    },
    {
      name: '思考状态',
      description: '沉思的姿态，适合工作思考时使用',
      duration: '5秒',
      icon: <Brain className="w-4 h-4" />,
      color: 'bg-purple-500'
    },
    {
      name: '淡入淡出',
      description: '优雅的出现和消失效果',
      duration: '4秒',
      icon: <Eye className="w-4 h-4" />,
      color: 'bg-gray-500'
    }
  ];

  return (
    <Card className="p-6">
      <h3 className="mb-4">动画说明</h3>
      <div className="space-y-3">
        {animations.map((anim, index) => (
          <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50">
            <div className={`p-2 rounded-full ${anim.color} text-white flex-shrink-0`}>
              {anim.icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-1">
                <h4 className="text-sm font-medium">{anim.name}</h4>
                <Badge variant="secondary" className="text-xs">
                  {anim.duration}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                {anim.description}
              </p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 p-4 bg-primary/5 rounded-lg">
        <h4 className="text-sm font-medium mb-2">使用提示</h4>
        <ul className="text-xs text-muted-foreground space-y-1">
          <li>• 点击动画模板可以快速加载预设动画</li>
          <li>• 可以在关键帧面板中调整动画参数</li>
          <li>• 时间轴支持精确的时间控制和编辑</li>
          <li>• 导出的JSON文件可以在桌宠软件中使用</li>
        </ul>
      </div>
    </Card>
  );
}