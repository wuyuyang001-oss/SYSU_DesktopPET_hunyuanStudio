import React, { useState, useRef, useCallback } from 'react';
import { Play, Pause, Square, Plus, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Slider } from './ui/slider';

export interface Keyframe {
  id: string;
  time: number;
  properties: {
    x: number;
    y: number;
    scale: number;
    rotation: number;
    opacity: number;
  };
}

interface TimelineProps {
  duration: number;
  currentTime: number;
  keyframes: Keyframe[];
  isPlaying: boolean;
  onTimeChange: (time: number) => void;
  onPlay: () => void;
  onPause: () => void;
  onStop: () => void;
  onAddKeyframe: (time: number) => void;
  onDeleteKeyframe: (keyframeId: string) => void;
  onSelectKeyframe: (keyframe: Keyframe) => void;
  selectedKeyframe?: Keyframe;
}

export function Timeline({
  duration,
  currentTime,
  keyframes,
  isPlaying,
  onTimeChange,
  onPlay,
  onPause,
  onStop,
  onAddKeyframe,
  onDeleteKeyframe,
  onSelectKeyframe,
  selectedKeyframe
}: TimelineProps) {
  const timelineRef = useRef<HTMLDivElement>(null);

  const handleTimelineClick = useCallback((e: React.MouseEvent) => {
    if (!timelineRef.current) return;
    
    const rect = timelineRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    const time = percentage * duration;
    
    onTimeChange(Math.max(0, Math.min(duration, time)));
  }, [duration, onTimeChange]);

  const formatTime = (time: number) => {
    const seconds = Math.floor(time);
    const milliseconds = Math.floor((time - seconds) * 100);
    return `${seconds}.${milliseconds.toString().padStart(2, '0')}s`;
  };

  return (
    <Card className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3>时间轴</h3>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAddKeyframe(currentTime)}
          >
            <Plus className="w-4 h-4 mr-1" />
            添加关键帧
          </Button>
          {selectedKeyframe && (
            <Button
              variant="destructive"
              size="sm"
              onClick={() => onDeleteKeyframe(selectedKeyframe.id)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* 播放控件 */}
      <div className="flex items-center space-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={isPlaying ? onPause : onPlay}
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </Button>
        <Button variant="outline" size="sm" onClick={onStop}>
          <Square className="w-4 h-4" />
        </Button>
        <span className="text-sm text-muted-foreground ml-4">
          {formatTime(currentTime)} / {formatTime(duration)}
        </span>
      </div>

      {/* 时间轴滑块 */}
      <div className="space-y-2">
        <Slider
          value={[currentTime]}
          max={duration}
          step={0.1}
          onValueChange={([value]) => onTimeChange(value)}
          className="w-full"
        />
      </div>

      {/* 时间轴视觉表示 */}
      <div className="relative">
        <div
          ref={timelineRef}
          className="h-16 bg-muted rounded-lg cursor-pointer relative overflow-hidden"
          onClick={handleTimelineClick}
        >
          {/* 时间刻度 */}
          <div className="absolute inset-0 flex">
            {Array.from({ length: Math.ceil(duration) + 1 }, (_, i) => (
              <div
                key={i}
                className="flex-1 border-r border-border last:border-r-0 flex items-end justify-center pb-1"
              >
                <span className="text-xs text-muted-foreground">{i}s</span>
              </div>
            ))}
          </div>

          {/* 关键帧标记 */}
          {keyframes.map((keyframe) => (
            <div
              key={keyframe.id}
              className={`absolute top-2 w-3 h-3 rounded-full cursor-pointer transform -translate-x-1/2 ${
                selectedKeyframe?.id === keyframe.id
                  ? 'bg-primary ring-2 ring-primary/50'
                  : 'bg-accent-foreground hover:bg-primary'
              }`}
              style={{ left: `${(keyframe.time / duration) * 100}%` }}
              onClick={(e) => {
                e.stopPropagation();
                onSelectKeyframe(keyframe);
              }}
            />
          ))}

          {/* 当前时间指示器 */}
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-primary z-10"
            style={{ left: `${(currentTime / duration) * 100}%` }}
          >
            <div className="absolute -top-1 -left-1 w-3 h-3 bg-primary rounded-full" />
          </div>
        </div>
      </div>

      {/* 关键帧列表 */}
      {keyframes.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm">关键帧列表</h4>
          <div className="space-y-1 max-h-32 overflow-y-auto">
            {keyframes
              .sort((a, b) => a.time - b.time)
              .map((keyframe) => (
                <div
                  key={keyframe.id}
                  className={`flex items-center justify-between p-2 rounded cursor-pointer ${
                    selectedKeyframe?.id === keyframe.id
                      ? 'bg-primary/10 border border-primary/20'
                      : 'bg-muted hover:bg-muted/80'
                  }`}
                  onClick={() => onSelectKeyframe(keyframe)}
                >
                  <span className="text-sm">
                    关键帧 {formatTime(keyframe.time)}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteKeyframe(keyframe.id);
                    }}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              ))}
          </div>
        </div>
      )}
    </Card>
  );
}