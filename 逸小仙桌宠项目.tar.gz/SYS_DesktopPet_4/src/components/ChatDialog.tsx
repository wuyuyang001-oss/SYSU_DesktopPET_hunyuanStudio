import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Send, 
  Mic, 
  MicOff, 
  Copy, 
  Square, 
  Settings,
  Volume2,
  VolumeX,
  User,
  Bot,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ChatMessage, VoiceSettings } from '../types';
import { usePetSettings } from '../hooks/usePetSettings';
import { useLayoutDetection, getPanelPosition } from '../hooks/useLayoutDetection';
import { dialogStyles } from '../data/characters';
import { toast } from 'sonner@2.0.3';

interface ChatDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
}

export function ChatDialog({ isOpen, onClose, onOpenSettings }: ChatDialogProps) {
  const { settings } = usePetSettings();
  const layoutInfo = useLayoutDetection('dialog');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    enabled: true,
    language: 'zh-CN',
    rate: 1,
    pitch: 1,
    volume: 0.8
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthesisRef = useRef<SpeechSynthesisUtterance | null>(null);

  const currentStyle = dialogStyles[settings.dialogStyle];

  // 初始化语音识别
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = voiceSettings.language;

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
        toast.error('语音识别失败，请重试');
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, [voiceSettings.language]);

  // 滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 初始问候
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const greeting = currentStyle.greetings[Math.floor(Math.random() * currentStyle.greetings.length)];
      const welcomeMessage: ChatMessage = {
        id: Date.now().toString(),
        type: 'assistant',
        content: greeting,
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
      
      // 自动播放问候语
      if (voiceSettings.enabled && !settings.isMuted) {
        speakText(greeting);
      }
    }
  }, [isOpen, currentStyle, voiceSettings.enabled, settings.isMuted]);

  // 语音合成
  const speakText = (text: string) => {
    if (!voiceSettings.enabled || settings.isMuted) return;

    // 停止当前播放
    speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = voiceSettings.language;
    utterance.rate = voiceSettings.rate;
    utterance.pitch = voiceSettings.pitch;
    utterance.volume = voiceSettings.volume;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synthesisRef.current = utterance;
    speechSynthesis.speak(utterance);
  };

  // 停止语音播放
  const stopSpeaking = () => {
    speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  // 开始语音识别
  const startListening = () => {
    if (!recognitionRef.current) {
      toast.error('您的浏览器不支持语音识别功能');
      return;
    }

    setIsListening(true);
    recognitionRef.current.start();
  };

  // 停止语音识别
  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
  };

  // 发送消息
  const handleSendMessage = async () => {
    if (!inputValue.trim() || isGenerating) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsGenerating(true);

    // 模拟AI回复（实际应该调用腾讯云API）
    try {
      const response = await simulateAIResponse(userMessage.content);
      
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
      
      // 自动播放回复
      if (voiceSettings.enabled && !settings.isMuted) {
        speakText(response);
      }
    } catch (error) {
      toast.error('获取回复失败，请重试');
    } finally {
      setIsGenerating(false);
    }
  };

  // 模拟AI回复（实际应该替换为腾讯云API调用）
  const simulateAIResponse = async (input: string): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    const responses = {
      warm: [
        '我理解你的想法，让我来帮助你解决这个问题。',
        '这确实是个很好的问题呢，我们一起来看看吧～',
        '谢谢你的提问，我很乐意为你解答。'
      ],
      passionate: [
        '太好了！我们来一起攻克这个难题！',
        '这个问题很有挑战性，但我相信我们能找到答案！',
        '让我们用满满的热情来解决这个问题吧！'
      ],
      diligent: [
        '根据您的问题，我将为您提供专业的解答。',
        '我已经分析了您的需求，现在为您详细说明。',
        '针对这个问题，我建议采用以下方案。'
      ]
    };

    const styleResponses = responses[settings.dialogStyle] || responses.warm;
    return styleResponses[Math.floor(Math.random() * styleResponses.length)];
  };

  // 复制消息
  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content);
    toast.success('已复制到剪贴板');
  };

  // 键盘事件
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  // 计算面板位置和样式
  const petSize = settings.size === 'small' ? 60 : settings.size === 'large' ? 140 : 100;
  const position = getPanelPosition(settings.position, petSize, layoutInfo, 'dialog');
  
  const getContainerStyle = () => {
    const baseStyle = {
      left: position.x,
      top: position.y,
    };

    switch (layoutInfo.mode) {
      case 'sidebar':
        return {
          ...baseStyle,
          width: 400,
          height: '100vh',
          maxWidth: 'none',
          maxHeight: 'none'
        };
      case 'compact':
        return {
          ...baseStyle,
          width: isExpanded ? 400 : 320,
          height: isExpanded ? 600 : 400,
          maxWidth: 'none',
          maxHeight: 'none'
        };
      default:
        return {
          width: '100%',
          maxWidth: '32rem', // max-w-2xl
          height: '600px'
        };
    }
  };

  const containerStyle = getContainerStyle();

  return (
    <AnimatePresence>
      {layoutInfo.mode === 'default' ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="w-full max-w-2xl h-[600px] flex flex-col"
          >
            <Card className="flex-1 flex flex-col shadow-xl">
              {/* 标题栏 */}
              <div className="flex items-center justify-between p-2 sm:p-4 border-b">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Bot className="w-4 h-4 text-primary-foreground" />
                </div>
                {layoutInfo.mode !== 'compact' || isExpanded ? (
                  <div>
                    <h3>智能助手</h3>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        {currentStyle.name}
                      </Badge>
                      {isSpeaking && (
                        <Badge variant="outline" className="text-xs">
                          <Volume2 className="w-3 h-3 mr-1" />
                          播放中
                        </Badge>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-sm">助手</div>
                )}
              </div>
              <div className="flex items-center space-x-1">
                {layoutInfo.mode === 'compact' && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsExpanded(!isExpanded)}
                  >
                    {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                  </Button>
                )}
                {(layoutInfo.mode !== 'compact' || isExpanded) && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={onOpenSettings}
                    >
                      <Settings className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setVoiceSettings(prev => ({ ...prev, enabled: !prev.enabled }))}
                    >
                      {voiceSettings.enabled && !settings.isMuted ? (
                        <Volume2 className="w-4 h-4" />
                      ) : (
                        <VolumeX className="w-4 h-4" />
                      )}
                    </Button>
                  </>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* 消息列表 */}
            <ScrollArea className="flex-1 p-2 sm:p-4">
              <div className="space-y-2 sm:space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`${
                        layoutInfo.mode === 'compact' && !isExpanded ? 'max-w-[95%]' : 'max-w-[80%]'
                      } rounded-lg p-2 sm:p-3 ${
                        message.type === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <div className="flex items-start space-x-2">
                        {((layoutInfo.mode !== 'compact' || isExpanded) && message.type === 'assistant') && (
                          <Bot className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        )}
                        {((layoutInfo.mode !== 'compact' || isExpanded) && message.type === 'user') && (
                          <User className="w-4 h-4 mt-0.5 flex-shrink-0" />
                        )}
                        <div className="flex-1">
                          <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                          {(layoutInfo.mode !== 'compact' || isExpanded) && (
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-xs opacity-60">
                                {message.timestamp.toLocaleTimeString()}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyMessage(message.content)}
                                className="h-6 px-2"
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {isGenerating && (
                  <div className="flex justify-start">
                    <div className="bg-muted rounded-lg p-3">
                      <div className="flex items-center space-x-2">
                        <Bot className="w-4 h-4" />
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            <Separator />

            {/* 输入区域 */}
            <div className="p-2 sm:p-4">
              <div className="flex items-end space-x-1 sm:space-x-2">
                <div className="flex-1">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder={
                      layoutInfo.mode === 'compact' && !isExpanded 
                        ? "输入消息..." 
                        : "输入消息或点击麦克风说话..."
                    }
                    disabled={isGenerating}
                    className="text-sm"
                  />
                </div>
                
                {/* 紧凑模式下简化按钮 */}
                {layoutInfo.mode === 'compact' && !isExpanded ? (
                  <>
                    <Button
                      variant={isListening ? 'destructive' : 'outline'}
                      size="sm"
                      onClick={isListening ? stopListening : startListening}
                      disabled={isGenerating}
                    >
                      {isListening ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
                    </Button>
                    <Button
                      onClick={handleSendMessage}
                      disabled={!inputValue.trim() || isGenerating}
                      size="sm"
                    >
                      <Send className="w-3 h-3" />
                    </Button>
                  </>
                ) : (
                  <>
                    {/* 语音按钮 */}
                    <Button
                      variant={isListening ? 'destructive' : 'outline'}
                      size="sm"
                      onClick={isListening ? stopListening : startListening}
                      disabled={isGenerating}
                    >
                      {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </Button>

                    {/* 停止播放按钮 */}
                    {isSpeaking && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={stopSpeaking}
                      >
                        <Square className="w-4 h-4" />
                      </Button>
                    )}

                    {/* 发送按钮 */}
                    <Button
                      onClick={handleSendMessage}
                      disabled={!inputValue.trim() || isGenerating}
                      size="sm"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </>
                )}
              </div>
              
              {isListening && (layoutInfo.mode !== 'compact' || isExpanded) && (
                <div className="mt-2 text-sm text-muted-foreground text-center">
                  正在监听，请说话...
                </div>
              )}
            </div>
            </Card>
          </motion.div>
        </div>
      ) : (
        <>
          <div 
            className="fixed inset-0 z-40 bg-transparent"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, x: layoutInfo.position === 'right' ? 50 : -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: layoutInfo.position === 'right' ? 50 : -50 }}
            className="fixed z-50 flex flex-col"
            style={containerStyle}
          >
            <Card className="flex-1 flex flex-col shadow-xl">
              {/* 标题栏 */}
              <div className="flex items-center justify-between p-2 sm:p-4 border-b">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <Bot className="w-4 h-4 text-primary-foreground" />
                  </div>
                  {layoutInfo.mode !== 'compact' || isExpanded ? (
                    <div>
                      <h3>智能助手</h3>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary" className="text-xs">
                          {currentStyle.name}
                        </Badge>
                        {isSpeaking && (
                          <Badge variant="outline" className="text-xs">
                            <Volume2 className="w-3 h-3 mr-1" />
                            播放中
                          </Badge>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-sm">助手</div>
                  )}
                </div>
                <div className="flex items-center space-x-1">
                  {layoutInfo.mode === 'compact' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsExpanded(!isExpanded)}
                    >
                      {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                    </Button>
                  )}
                  {(layoutInfo.mode !== 'compact' || isExpanded) && (
                    <>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={onOpenSettings}
                      >
                        <Settings className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setVoiceSettings(prev => ({ ...prev, enabled: !prev.enabled }))}
                      >
                        {voiceSettings.enabled && !settings.isMuted ? (
                          <Volume2 className="w-4 h-4" />
                        ) : (
                          <VolumeX className="w-4 h-4" />
                        )}
                      </Button>
                    </>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClose}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* 消息列表 */}
              <ScrollArea className="flex-1 p-2 sm:p-4">
                <div className="space-y-2 sm:space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`${
                          layoutInfo.mode === 'compact' && !isExpanded ? 'max-w-[95%]' : 'max-w-[80%]'
                        } rounded-lg p-2 sm:p-3 ${
                          message.type === 'user'
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted'
                        }`}
                      >
                        <div className="flex items-start space-x-2">
                          {((layoutInfo.mode !== 'compact' || isExpanded) && message.type === 'assistant') && (
                            <Bot className="w-4 h-4 mt-0.5 flex-shrink-0" />
                          )}
                          {((layoutInfo.mode !== 'compact' || isExpanded) && message.type === 'user') && (
                            <User className="w-4 h-4 mt-0.5 flex-shrink-0" />
                          )}
                          <div className="flex-1">
                            <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                            {(layoutInfo.mode !== 'compact' || isExpanded) && (
                              <div className="flex items-center justify-between mt-2">
                                <span className="text-xs opacity-60">
                                  {message.timestamp.toLocaleTimeString()}
                                </span>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => copyMessage(message.content)}
                                  className="h-6 px-2"
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}

                  {isGenerating && (
                    <div className="flex justify-start">
                      <div className="bg-muted rounded-lg p-2 sm:p-3">
                        <div className="flex items-center space-x-2">
                          <Bot className="w-4 h-4" />
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-current rounded-full animate-bounce" />
                            <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:0.1s]" />
                            <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:0.2s]" />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>

              {/* 输入区域 */}
              <div className="p-2 sm:p-4">
                <div className="flex items-end space-x-1 sm:space-x-2">
                  <div className="flex-1">
                    <Input
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder={
                        layoutInfo.mode === 'compact' && !isExpanded 
                          ? "输入消息..." 
                          : "输入消息或点击麦克风说话..."
                      }
                      disabled={isGenerating}
                      className="text-sm"
                    />
                  </div>
                  
                  {/* 紧凑模式下简化按钮 */}
                  {layoutInfo.mode === 'compact' && !isExpanded ? (
                    <>
                      <Button
                        variant={isListening ? 'destructive' : 'outline'}
                        size="sm"
                        onClick={isListening ? stopListening : startListening}
                        disabled={isGenerating}
                      >
                        {isListening ? <MicOff className="w-3 h-3" /> : <Mic className="w-3 h-3" />}
                      </Button>
                      <Button
                        onClick={handleSendMessage}
                        disabled={!inputValue.trim() || isGenerating}
                        size="sm"
                      >
                        <Send className="w-3 h-3" />
                      </Button>
                    </>
                  ) : (
                    <>
                      {/* 语音按钮 */}
                      <Button
                        variant={isListening ? 'destructive' : 'outline'}
                        size="sm"
                        onClick={isListening ? stopListening : startListening}
                        disabled={isGenerating}
                      >
                        {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                      </Button>

                      {/* 停止播放按钮 */}
                      {isSpeaking && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={stopSpeaking}
                        >
                          <Square className="w-4 h-4" />
                        </Button>
                      )}

                      {/* 发送按钮 */}
                      <Button
                        onClick={handleSendMessage}
                        disabled={!inputValue.trim() || isGenerating}
                        size="sm"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
                
                {isListening && (layoutInfo.mode !== 'compact' || isExpanded) && (
                  <div className="mt-2 text-sm text-muted-foreground text-center">
                    正在监听，请说话...
                  </div>
                )}
              </div>
            </Card>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}