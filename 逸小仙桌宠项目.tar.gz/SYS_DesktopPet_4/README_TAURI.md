# 逸小仙 - Tauri桌面宠物应用

## 项目概述

这是一个基于Tauri框架开发的桌面宠物应用，将原有的网页版桌面宠物转换为独立的桌面应用程序。宠物可以在桌面上自由活动，支持点击穿透功能，不会影响正常的桌面操作。

## 主要特性

### 桌面应用特性
- **全屏覆盖**：窗口覆盖整个屏幕，不显示边框
- **透明背景**：窗口背景完全透明，仅显示宠物和交互元素
- **始终置顶**：窗口始终显示在其他窗口之上
- **点击穿透**：当鼠标不在宠物上时，允许点击穿透到桌面其他内容

### 宠物功能
- **经典原像**：显示传统的桌宠形象
- **Q萌心情**：6种不同的表情动画状态
  - 哼个小曲 (🎶)
  - 发射心心 (❤️)
  - 畅快大笑 (😀)
  - 我在思考 (🤔)
  - 顶住鸭力 (🦆)
  - 赞赞能量 (👍)
- **拖拽移动**：可以拖拽宠物到桌面任意位置
- **右键菜单**：提供切换状态、打开对话、查看通知等功能

## 技术栈

- **前端**：React + TypeScript + Vite
- **桌面框架**：Tauri
- **动画**：Framer Motion
- **UI组件**：Radix UI + Tailwind CSS
- **后端**：Rust

## 安装和运行

### 环境要求
- Node.js 18+
- Rust 1.77+
- Tauri CLI

### 安装依赖
```bash
npm install
```

### 开发模式
```bash
npm run tauri:dev
```

### 构建应用
```bash
npm run tauri:build
```

## 项目结构

```
src/
├── components/          # React组件
│   ├── DesktopPet.tsx  # 主宠物组件
│   ├── PetContextMenu.tsx # 右键菜单
│   └── ui/            # UI组件库
├── hooks/              # 自定义Hooks
│   ├── useClickThrough.ts # 点击穿透功能
│   └── usePetSettings.ts  # 宠物设置
├── data/               # 数据配置
│   └── characters.ts   # 角色和心情配置
├── types/              # TypeScript类型定义
└── assets/             # 静态资源

src-tauri/              # Tauri后端
├── src/
│   └── lib.rs         # Rust主代码
└── Cargo.toml         # Rust依赖配置
```

## 图像资源位置

### 经典原像状态
- 主图像：`/src/assets/f907a1206897595d95a8bb4eb7c6380b1fb04949.png`
- 角色图像：`/characters/{characterId}.png`

### Q萌心情状态
- 图像路径：`/emoji/{moodId}_{frameNumber}.png`
- 例如：`/emoji/humming_01.png` 到 `/emoji/humming_08.png`

## 点击穿透实现

应用通过以下方式实现点击穿透：

1. **Rust后端**：使用系统API设置窗口的点击穿透属性
   - Windows：使用`WS_EX_TRANSPARENT`样式
   - macOS：使用`setIgnoresMouseEvents`方法
   - Linux：待实现

2. **前端检测**：通过鼠标移动事件检测鼠标是否在宠物上
   - 在宠物上：禁用点击穿透，允许交互
   - 不在宠物上：启用点击穿透，允许桌面操作

## 开发说明

### 添加新的心情状态
1. 在`src/data/characters.ts`中的`emojiMoods`数组添加新状态
2. 准备8帧PNG图像，命名为`{moodId}_01.png`到`{moodId}_08.png`
3. 将图像放置在`/emoji/`目录下

### 修改窗口属性
在`src-tauri/tauri.conf.json`中修改窗口配置：
- `fullscreen`: 是否全屏
- `transparent`: 是否透明
- `alwaysOnTop`: 是否置顶
- `decorations`: 是否显示边框

## 注意事项

1. 首次运行需要安装Rust和Tauri CLI
2. 点击穿透功能在不同操作系统上的实现方式不同
3. 透明窗口在某些系统上可能有性能影响
4. 建议在开发时使用`npm run tauri:dev`进行调试

## 故障排除

### 常见问题
1. **Rust编译错误**：确保Rust版本为1.77+
2. **点击穿透不工作**：检查系统权限和窗口管理器设置
3. **图像不显示**：检查图像路径和文件是否存在
4. **窗口不透明**：确认系统支持透明窗口

### 调试技巧
- 使用浏览器开发者工具调试前端
- 查看Tauri控制台输出
- 检查系统日志中的错误信息
