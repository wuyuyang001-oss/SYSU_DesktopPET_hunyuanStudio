#!/usr/bin/env python3
"""
创建桌宠应用图标
"""
from PIL import Image, ImageDraw, ImageFont
import os

def create_app_icon():
    # 创建512x512的图标
    size = 512
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # 绘制圆形背景
    margin = 50
    draw.ellipse([margin, margin, size-margin, size-margin], 
                fill=(74, 144, 226, 255), outline=(255, 255, 255, 255), width=8)
    
    # 绘制文字 "逸"
    try:
        # 尝试使用系统字体
        font = ImageFont.truetype("/System/Library/Fonts/PingFang.ttc", 200)
    except:
        # 如果系统字体不可用，使用默认字体
        font = ImageFont.load_default()
    
    # 计算文字位置（居中）
    text = "逸"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x = (size - text_width) // 2
    y = (size - text_height) // 2 - 20
    
    # 绘制白色文字
    draw.text((x, y), text, fill=(255, 255, 255, 255), font=font)
    
    # 保存图标
    icon_path = "/Users/wuyuyang/DesktopPet/SYS_DesktopPet_4/逸小仙桌宠.app/Contents/Resources/icon.icns"
    img.save(icon_path.replace('.icns', '.png'))
    
    print(f"图标已创建: {icon_path.replace('.icns', '.png')}")
    return icon_path.replace('.icns', '.png')

if __name__ == "__main__":
    create_app_icon()



